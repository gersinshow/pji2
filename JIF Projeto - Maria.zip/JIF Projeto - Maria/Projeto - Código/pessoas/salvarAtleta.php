<?php
include('config.php');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(400);
    echo json_encode(array('mensagem' => 'Erro na requisição. Este script aceita apenas requisições do tipo POST.'));
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Obtenha os dados do POST
        $responsavel = $_POST['responsavel'];
        $nome = $_POST['nome'];
        $cpf = $_POST['cpf'];
        $rg = $_POST['rg'];
        $ra = $_POST['ra'];
        $datanasc = $_POST['datanasc'];
        $sexo = $_POST['sexo'];

        // Inicie uma transação
        $conexao->begin_transaction();

        // Verifique se o CPF já existe
        if ($cpf) {
            // Atualizar pessoa existente
            $sql = "UPDATE pessoa SET nome=?, sexo=?, datanasc=?, rg=?, ra=?, responsavel=? WHERE cpf=?";
            $stmt = $conexao->prepare($sql);
            $stmt->bind_param("sssssss", $nome, $sexo, $datanasc, $rg, $ra, $responsavel, $cpf);
            $stmt->execute();

            if ($stmt->errno !== 0) {
                // Erro na atualização
                throw new Exception('Erro ao atualizar pessoa: ' . $stmt->error);
            } else {
                // Lógica para inserir ou atualizar na tabela pessoa_tipo
                $tipoPessoaId = 1;

                $sqlCheck = "SELECT COUNT(*) as count FROM pessoa_tipo WHERE cpf_pessoa=? AND id_tipo=?";
                $stmtCheck = $conexao->prepare($sqlCheck);
                $stmtCheck->bind_param("si", $cpf, $tipoPessoaId);
                $stmtCheck->execute();
                $result = $stmtCheck->get_result();
                $row = $result->fetch_assoc();

                if ($row['count'] > 0) {
                    // Já existe um registro, então atualiza
                    $sqlUpdate = "UPDATE pessoa_tipo SET id_tipo=? WHERE cpf_pessoa=?";
                    $stmtUpdate = $conexao->prepare($sqlUpdate);
                    $stmtUpdate->bind_param("is", $tipoPessoaId, $cpf);
                    $stmtUpdate->execute();
                } else {
                    // Não existe um registro, então insere
                    $sqlInsert = "INSERT INTO pessoa_tipo (cpf_pessoa, id_tipo) VALUES (?, ?)";
                    $stmtInsert = $conexao->prepare($sqlInsert);
                    $stmtInsert->bind_param("si", $cpf, $tipoPessoaId);
                    $stmtInsert->execute();

                    // Verifica se ocorreu um erro na inserção
                    if ($stmtInsert->errno !== 0) {
                        throw new Exception('Erro ao inserir pessoa_tipo: ' . $stmtInsert->error);
                    }
                }

                // Sucesso
                $conexao->commit();
                echo json_encode(array('mensagem' => 'Dados do atleta atualizados com sucesso.'));
            }
        } else {
            // Retornar algum erro se o CPF não estiver presente
            throw new Exception('Erro: CPF não fornecido.');
        }
    } catch (Exception $e) {
        // Se ocorrer uma exceção, faça o rollback da transação e retorne o erro
        $conexao->rollback();
        http_response_code(500);
        echo json_encode(array('mensagem' => $e->getMessage()));
    }
} else {
    // Retornar algum erro se a requisição não for do tipo POST
    http_response_code(400);
    echo json_encode(array('mensagem' => 'Erro na requisição.'));
}

?>
