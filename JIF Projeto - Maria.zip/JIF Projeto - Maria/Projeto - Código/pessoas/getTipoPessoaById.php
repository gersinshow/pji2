<?php
// getTipoPessoaById.php

include('config.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Verifique a conexão
    if ($conexao->connect_error) {
        die("Conexão falhou: " . $conexao->connect_error);
    }

    // Evite SQL Injection escapando os parâmetros
    $tipoId = $conexao->real_escape_string($_POST['tipoId']);

    $sql = "SELECT * FROM tipos_pessoa WHERE id_tipo = '$tipoId'";
    $result = $conexao->query($sql);

    // Verifique se há resultados
    if ($result->num_rows > 0) {
        // Converta os resultados em um array associativo
        $tipoPessoa = $result->fetch_assoc();

        // Libere os resultados e feche a conexão
        $result->close();
        $conexao->close();

        // Retorne o array associativo como JSON
        echo json_encode($tipoPessoa);
    } else {
        // Se não houver resultados, retorne um array vazio como JSON
        echo json_encode(array());
    }
} else {
    // Retornar algum erro se a requisição não for do tipo POST
    http_response_code(400);
    echo json_encode(array('mensagem' => 'Erro na requisição.'));
}
?>


