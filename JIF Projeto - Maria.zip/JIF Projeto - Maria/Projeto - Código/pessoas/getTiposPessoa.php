<?php
include('config.php');

$query = "SELECT * FROM tipo_pessoa";
$result = mysqli_query($conexao, $query);

$tipos = array();
while ($row = mysqli_fetch_assoc($result)) {
    $tipos[] = $row;
}

echo json_encode($tipos);
?>
