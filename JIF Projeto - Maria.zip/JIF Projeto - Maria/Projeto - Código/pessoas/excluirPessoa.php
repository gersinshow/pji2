<?php
include('config.php');

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Obtém o ID da pessoa a ser excluída
if (isset($_POST['idPessoa'])) {
    $idPessoa = $_POST['idPessoa'];
} else {
    http_response_code(400);
    echo json_encode(array('mensagem' => 'ID da pessoa não fornecido.'));
    exit; 
}

// Inicia uma transação para garantir consistência
$conexao->begin_transaction();

try {
    // Excluir registros relacionados na tabela equipe_atleta
    $sqlExcluirEquipeAtleta = "DELETE FROM equipe_atleta WHERE cpf = ?";
    $stmtExcluirEquipeAtleta = $conexao->prepare($sqlExcluirEquipeAtleta);
    $stmtExcluirEquipeAtleta->bind_param('s', $idPessoa);
    $stmtExcluirEquipeAtleta->execute();

    // Excluir registros relacionados na tabela equipe_delegacao
    $sqlExcluirEquipeDelegacao = "DELETE FROM equipe_delegacao WHERE cpf = ?";
    $stmtExcluirEquipeDelegacao = $conexao->prepare($sqlExcluirEquipeDelegacao);
    $stmtExcluirEquipeDelegacao->bind_param('s', $idPessoa);
    $stmtExcluirEquipeDelegacao->execute();

    // Excluir registros relacionados na tabela pessoa_tipo
    $sqlExcluirPessoaTipo = "DELETE FROM pessoa_tipo WHERE cpf_pessoa = ?";
    $stmtExcluirPessoaTipo = $conexao->prepare($sqlExcluirPessoaTipo);
    $stmtExcluirPessoaTipo->bind_param('s', $idPessoa);
    $stmtExcluirPessoaTipo->execute();

    // Exclui a pessoa da tabela pessoa
    $sqlExcluirPessoa = "DELETE FROM pessoa WHERE cpf = ?";
    $stmtExcluirPessoa = $conexao->prepare($sqlExcluirPessoa);
    $stmtExcluirPessoa->bind_param('s', $idPessoa);
    $stmtExcluirPessoa->execute();

    // Comita a transação se tudo ocorrer sem erros
    $conexao->commit();

    // Responde com uma mensagem de sucesso em formato JSON
    echo json_encode(array('mensagem' => 'Pessoa excluída com sucesso.'));
} catch (mysqli_sql_exception $e) {
    // Lidar com a exceção do MySQLi
    error_log('Erro MySQLi: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(array('mensagem' => 'Erro MySQLi ao excluir pessoa.', 'erro' => $e->getMessage()));
} finally {
    // Fecha a conexão com o banco de dados
    $conexao->close();
}
?>
