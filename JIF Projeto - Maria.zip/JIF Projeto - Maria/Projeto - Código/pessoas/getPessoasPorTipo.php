<?php
include('config.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tipoId = $_POST['tipoId'];

    // Substitua a consulta abaixo pela lógica para obter a lista de pessoas com base no tipo selecionado
    $query = "SELECT * FROM pessoa WHERE tipo_pessoa_id = $tipoId";
    $result = mysqli_query($conexao, $query);

    $pessoas = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $pessoas[] = $row;
    }

    echo json_encode($pessoas);
}
?>
