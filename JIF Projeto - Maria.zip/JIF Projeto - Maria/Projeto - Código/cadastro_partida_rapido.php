<?php
session_start();
include('config.php');

// Verifica se o usuário está autenticado como administrador
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: login.php");
    exit();
}


?>


<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css_2/style_atleta.css">
    <link rel="shortcut icon" href="img/Logo.ico">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <title>Cadastro de Partida</title>
</head>
<style>
    .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .back-button {
        padding: 5px 10px;
        text-decoration: none;
        background-color: green; 
        border: none;
        border-radius: 20px;
        color: white;
        cursor: pointer;
        font-size: 16px;
        transition: all 0.4s ease;
    }

    .back-button:hover {
        background-color: darkgreen; 
    }
</style>
<body>
    <div class="boxzinha">
        <div class="formulario-boxzinha">
            <div class="header">
                <h2>Cadastro de Partida</h2>
                <a class="back-button" href="index2.php">Página Inicial</a>
                <a class="back-button" href="cadastros-gerais.php">Voltar</a>
            </div>

            <form method="POST">

                <div class="inputszinha">
                        <label for="nome_campeonato">Nome do Campeonato</label>
                        <select name="nome_campeonato" id="nome_campeonato">
                        <?php

                            $conexao = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName, $dbPorta);
                            // Recupera as opções do banco de dados
                            $sql = "SELECT id_campeonato, titulo FROM campeonato";
                            $resultado = $conexao->query($sql);
                                if ($resultado->num_rows > 0) {
                                while ($row = $resultado->fetch_assoc()) {
                                    echo '<option value="'.$row["id_campeonato"].'">'.$row["titulo"].' </option>';
                                }
                            } else {
                                echo '<option value="">Nenhuma campeonato cadastrado</option>';
                            }
                        ?>
                        </select>
                    </div>
                   
                <div class="inputszinha">
                    <label for="modalidade">Modalidade</label>
                    <select name="modalidade" id="modalidade">
                        <option value="Futsal">Futsal</option>
                        <option value="Vôlei">Vôlei</option>
                        <option value="Basquete">Basquete</option>
                        <option value="Handebol">Handebol</option>
                        <option value="Queimada">Queimada</option>
                    </select>
                </div>

                <div class="inputszinha">
                    <label for="data_partida">Data da partida</label>
                    <input type="date" id="data_partida" name="data_partida" placeholder="Digite a data da partida" >
                </div>

                <div class="inputszinha">
                    <label for="nome_equipe1">Equipe 1</label>
                    <select name="nome_equipe1" id="nome_equipe1">
                    <?php

                        $conexao = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName, $dbPorta);
                        // Recupera as opções do banco de dados
                        $sql = "SELECT id_equipe, nome FROM equipe";
                        $resultado = $conexao->query($sql);
                            if ($resultado->num_rows > 0) {
                            while ($row = $resultado->fetch_assoc()) {
                                echo '<option value="'.$row["id_equipe"].'">'.$row["nome"].' </option>';
                            }
                        } else {
                            echo '<option value="">Nenhuma equipe cadastrada</option>';
                        }
                    ?>
                    </select>
                </div>

                
                <div class="inputszinha">
                    <label for="resultado_equipe1">Resultado equipe 1</label>
                    <input type="number" id="resultado_equipe1" name="resultado_equipe1" placeholder="Digite o resultado da equipe 1" >
                </div>


                <div class="inputszinha">
                    <label for="nome_equipe2">Equipe 2</label>
                    <select name="nome_equipe2" id="nome_equipe2">
                    <?php

                        $conexao = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName, $dbPorta);
                        // Recupera as opções do banco de dados
                        $sql = "SELECT id_equipe, nome FROM equipe";
                        $resultado = $conexao->query($sql);
                            if ($resultado->num_rows > 0) {
                            while ($row = $resultado->fetch_assoc()) {
                                echo '<option value="'.$row["id_equipe"].'">'.$row["nome"].' </option>';
                            }
                        } else {
                            echo '<option value="">Nenhuma equipe cadastrada</option>';
                        }
                    ?>
                    </select>
                </div>

                <div class="inputszinha">
                    <label for="resultado_equipe2">Resultado equipe 2 </label>
                    <input type="number" id="resultado_equipe2" name="resultado_equipe2" placeholder="Digite o resultado da equipe 2 " >
                </div>
              
                
                <div class="inputszinha">
                    <button type="submit" name="submit">Cadastrar</button>
                </div>

            </form>
            <br><br>

            <h2>Lista de Partidas</h2>
            <br>

            <table class="table">
                <thead class="table-dark" id = "tableHeader">
                    


                </thead>
                <tbody id="partidaTableBody">
                    <!-- A tabela será preenchida dinamicamente com JavaScript -->

                </tbody>
            </table>

            </div>
        </div>

    <!-- Modal de Edição -->
    <div class="modal fade" id="editarModal" tabindex="-1" role="dialog" aria-labelledby="editarModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editarModalLabel">Editar Partida</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <label for="editNome">Nome do Campeonato</label>
                        <select name="editNome" id="editNome">
                        <?php

                            $conexao = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName, $dbPorta);
                            // Recupera as opções do banco de dados
                            $sql = "SELECT id_campeonato, titulo FROM campeonato";
                            $resultado = $conexao->query($sql);
                                if ($resultado->num_rows > 0) {
                                while ($row = $resultado->fetch_assoc()) {
                                    echo '<option value="'.$row["id_campeonato"].'">'.$row["titulo"].' </option>';
                                }
                            } else {
                                echo '<option value="">Nenhuma campeonato cadastrado</option>';
                            }
                        ?>
                        </select>
                        <br><br>
                        <div class="inputszinha">
                    <label for="editmodalidade">Modalidade</label>
                    <select name="editmodalidade" id="editmodalidade">
                        <option value="Futsal">Futsal</option>
                        <option value="Vôlei">Vôlei</option>
                        <option value="Basquete">Basquete</option>
                        <option value="Handebol">Handebol</option>
                        <option value="Queimada">Queimada</option>
                    </select>
                </div>
                <br><br>
                    <label for="editData">Data da Partida</label>
                    <input type="date" class="form-control" id="editData" name="editData" required>
                   
                    <br>
                    <label for="editResultado1">Resultado da Equipe 1</label>
                    <input type="number" class="form-control" id="editResultado1" name="editResultado1" required>
                    <br>
                
                    <label for="editResultado2">Resultado da Equipe 2</label>
                    <input type="number" class="form-control" id="editResultado2" name="editResultado2" required>
                    <br>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                    <button type="button" class="btn btn-primary" id="btnSalvar">Salvar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal de Confirmação de Exclusão -->
    <div class="modal fade" id="confirmDeleteModal" tabindex="-1" role="dialog" aria-labelledby="confirmDeleteModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="confirmDeleteModalLabel">Confirmar Exclusão</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Deseja realmente excluir esta Partida?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-danger" id="confirmDeleteBtn">Excluir</button>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>

    <!-- Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
    var idPartidaEditando = null;

    $(document).ready(function () {

        // Adicione um manipulador de eventos para o envio do formulário
        $('form').submit(function (e) {
            e.preventDefault(); // Evite o envio padrão do formulário

            // Obtenha os dados do formulário
            var nomeCampeonato = $('#nome_campeonato').val();
            var dataPartida = $('#data_partida').val();
            var modalidade = $('#modalidade').val();
            var nomeEquipe1 = $('#nome_equipe1').val();
            var resultadoEquipe1 = $('#resultado_equipe1').val();
            var nomeEquipe2 = $('#nome_equipe2').val();
            var resultadoEquipe2 = $('#resultado_equipe2').val();

            // Enviar dados via AJAX
            $.ajax({
                url: 'inserir_partida.php',
                type: 'POST',
                data: {
                    nome_campeonato: $('#nome_campeonato').val(),
                    data_partida: $('#data_partida').val(),
                    modalidade: $('#modalidade').val(),
                    nome_equipe1: $('#nome_equipe1').val(),
                    resultado_equipe1: $('#resultado_equipe1').val(),
                    nome_equipe2: $('#nome_equipe2').val(),
                    resultado_equipe2: $('#resultado_equipe2').val()
                },
                dataType: 'json',
                success: function (response) {
                    // Lógica de tratamento após inserção bem-sucedida
                    if (response.success) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Sucesso',
                            text: response.message,
                            showCancelButton: false,
                            confirmButtonColor: '#3085d6',
                            confirmButtonText: 'Fechar'
                        });

                        // Limpe os campos do formulário após o sucesso
                        $('#nome_campeonato').val('');
                        $('#data_partida').val('');
                        $('#modalidade').val('');
                        $('#nome_equipe1').val('');
                        $('#resultado_equipe1').val('');
                        $('#nome_equipe2').val('');
                        $('#resultado_equipe2').val('');

                        // Recarregue a tabela de partidas
                        carregarPartidas();
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Erro',
                            text: response.message,
                            showConfirmButton: false,
                            timer: 1500
                        });
                    }
                },
                error: function (xhr, status, error) {
                    console.error(xhr.responseText);
                    // Lógica de tratamento de erro, se necessário
                    Swal.fire({
                        icon: 'error',
                        title: 'Erro',
                        text: 'Erro ao processar a solicitação.',
                        showConfirmButton: false,
                        timer: 1500
                    });
                }
            });
        });

         // Função para carregar pessoas com base no tipo selecionado
         window.carregarPartidas = function () {
            $.ajax({
                url: 'carregarPartidas.php',
                type: 'POST',
                data: {},
                dataType: 'json',
                success: function (data) {
                    console.log(data);
                    // Limpa a tabela antes de preenchê-la
                    $('#partidaTableBody').empty();

                    if (data.length > 0) {
                        construirCabecalho();
                        preencherTabela(data);
                    } else {
                        // Se não houver torneios, exibe a mensagem "Nenhum Torneio Foi Inserido Ainda"
                        $('#tableHeader').empty();
                        $('#partidaTableBody').html('<p> Nenhuma Partida Foi Inserida Ainda</p>');
                    }
                },
                error: function (xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        };

        // Função para construir o cabeçalho da tabela
        function construirCabecalho() {
            var header = '<tr>' +
                '<th scope="col" class="text-center">ID Partida</th>' +
                '<th scope="col" class="text-center">Campeonato</th>' +
                '<th scope="col" class="text-center">Data</th>' +
                '<th scope="col" class="text-center">Modalidade</th>' +
        
                '<th scope="col" class="text-center">Resultado Equipe 1</th>' +
         
                '<th scope="col" class="text-center">Resultado Equipe 2</th>' +
                '<th scope="col" class="text-center">Editar</th>' +
                '<th scope="col" class="text-center">Excluir</th>' +
                '</tr>';
            $('#tableHeader').html(header);
        }

        // Função para preencher a tabela com dados
        function preencherTabela(data) {
            $.each(data, function (index, partida) {
                var row = '<tr>' +
                    '<td class="text-center">' + partida.id_partida + '</td>' +
                    '<td class="text-center">' + partida.nome_campeonato + '</td>' +
                    '<td class="text-center">' + partida.data_partida + '</td>' +
                    '<td class="text-center">' + partida.modalidade + '</td>' +
                  
                    '<td class="text-center">' + partida.resultado_equipe1 + '</td>' +
            
                    '<td class="text-center">' + partida.resultado_equipe2 + '</td>' +
                    '<td class="text-center"><button class="btn btn-primary" data-id="' + partida.id_partida + '" onclick="abrirModalEditar(' + partida.id_partida + ')">Editar</button></td>' +
                    '<td class="text-center"><button class="btn btn-danger" data-id="' + partida.id_partida + '" onclick="confirmarExclusao(' + partida.id_partida + ')">Excluir</button></td>' +
                    '</tr>';
                $('#partidaTableBody').append(row);
            });
        }

        window.abrirModalEditar = function (idPartida) {
            // Adaptação para obter os dados da partida correspondente
            $.ajax({
                url: 'getPartidaById.php',
                type: 'POST',
                data: { idPartida: idPartida },
                dataType: 'json',
                success: function (data) {
                    console.log('Dados da Partida:', data);
                    console.log('idPartida:', idPartida);

                    if (data) {
                        // Lógica para preencher os campos do modal com os dados da partida

                        // Adapte as linhas para preencher os campos do tipo "select" (dropdown)
                        $('#editNome').val(data.nome_campeonato);
                        $('#editData').val(data.data_partida);
                        $('#editmodalidade').val(data.modalidade);
                        $('#editResultado1').val(data.resultado_equipe1);
                        $('#editResultado2').val(data.resultado_equipe2);

                        // Define o idPartidaEditando global
                        idPartidaEditando = idPartida;

                        // Abre o modal
                        $('#editarModal').modal('show');
                    } else {
                        console.error('Partida não encontrada.');
                    }
                },
                error: function (xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        };


        carregarPartidas();

        function abrirModalEditar(idPartida) {
            console.log('Abrindo modal para idPartida:', idPartida);

            $.ajax({
                url: 'getPartidaById.php',
                type: 'POST',
                data: { idPartida: idPartida },
                dataType: 'json',
                success: function (data) {
                    console.log('Dados da Partida:', data);
                    console.log('idPartida:', idPartida);

                    // Lógica para preencher os campos do modal com os dados da partida

                    // Adapte as linhas para preencher os campos do tipo "select" (dropdown)
                  
                    $('#editNome').val(data.nome_campeonato);
                    $('#editData').val(data.data_partida);
                    $('#editmodalidade').val(data.modalidade);
                 
                    $('#editResultado1').val(data.resultado_equipe1);
                  
                    $('#editResultado2').val(data.resultado_equipe2);

                    // Abre o modal
                    $('#editarModal').modal('show');
                },
                error: function (xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });

            idPartidaEditando = null;
        }

        
        function salvarPartida() {
            // Obtenha os valores selecionados nos campos do tipo "select"
            var nomeCampeonato = $('#editNome').val();
            var dataPartida = $('#editData').val();
            var modalidade = $('#editmodalidade').val();
        
            var resultadoEquipe1 = $('#editResultado1').val();
       
            var resultadoEquipe2 = $('#editResultado2').val();

            $.ajax({
                url: 'salvarPartida.php',
                type: 'POST',
                data: {
                    idPartida: idPartidaEditando,
                    nomeCampeonato: nomeCampeonato,
                    dataPartida: dataPartida,
                    modalidade: modalidade,
                   
                    resultadoEquipe1: resultadoEquipe1,
                   
                    resultadoEquipe2: resultadoEquipe2
                },
                success: function (response) {
                    console.log(response);
                    // Lógica de tratamento após salvar os dados da partida

                    Swal.fire({
                        icon: 'success',
                        title: 'Partida salva com sucesso!',
                        showConfirmButton: false,
                        timer: 1500  // Fecha automaticamente após 1.5 segundos
                    });

                    // Fecha o modal genérico
                    $('#editarModal').modal('hide');

                    // Recarrega a lista de partidas após salvar
                    carregarPartidas();
                },
                error: function (xhr, status, error) {
                    console.error(xhr.responseText);
                    // Lógica de tratamento de erro, se necessário
                }
            });

            // Limpa a variável global após salvar
            idPartidaEditando = null;
        }


        // Adicione um parâmetro para receber o idPartida na função confirmarExclusao
        window.confirmarExclusao = function (idPartida) {
            console.log('ID da Partida a ser excluído:', idPartida);
            $('#confirmDeleteModal').modal('show');

            // Define a função de confirmação de exclusão no botão de confirmação
            $('#confirmDeleteBtn').off('click').on('click', function () {
                // AJAX para excluir a partida do banco de dados
                $.ajax({
                    url: 'excluirPartida.php',
                    type: 'POST',
                    data: { id_partida: idPartida }, // Ajuste o nome do parâmetro para o correto
                    success: function (response) {
                        console.log(response);
                        // Fecha o modal de confirmação de exclusão
                        $('#confirmDeleteModal').modal('hide');

                        // Exibe uma mensagem de sucesso usando SweetAlert2
                        Swal.fire({
                            icon: 'success',
                            title: 'Partida excluída com sucesso!',
                            showConfirmButton: false,
                            timer: 1500  // Fecha automaticamente após 1.5 segundos
                        });

                        // Recarrega a lista de partidas após excluir
                        carregarPartidas();
                    },
                    error: function (xhr, status, error) {
                        //console.error(xhr.responseText);

                        // Adicione o alerta de erro do SweetAlert2
                        Swal.fire({
                            icon: 'error',
                            title: 'Erro ao excluir partida',
                            text: 'Ocorreu um erro ao excluir a partida. Verifique se não existem dados associados em outras tabelas.',
                            footer: 'Exclua os dados correspondentes para efetuar a exclusão.'
                        });

                        $('#confirmDeleteModal').modal('hide');
                    }
                });
            });
        };



        // Adicione a lógica para o botão Salvar no modal genérico
        $('#btnSalvar').on('click', function () {
            salvarPartida();
        });

        // Adicione um manipulador de eventos para o clique no botão "Editar"
        $('#partidaTableBody').on('click', '.btn-primary', function() {
            // Obtenha o idTorneio da linha da tabela
            var idPartida = $(this).closest('tr').find('.btn-primary').data('id');
            
            // Chame abrirModalEditar passando o idTorneio
            abrirModalEditar(idPartida);
        });
    });
    </script>

</body>

</html>