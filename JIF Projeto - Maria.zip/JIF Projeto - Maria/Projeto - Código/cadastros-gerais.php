<?php
session_start();

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: login.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css_2/style_cadastros-gerais.css">
    <link rel="shortcut icon" href="img/Logo.ico">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script>
        $(document).ready(function() {
            $(".menu").hide();
            $(".menu1").hide();
            $("#menuPessoas").click(function() {
                $(".menu").toggle();
            });
            $("#menuCampeonato").click(function() {
                $(".menu1").toggle();
            });
        });
    </script>
    <title>Cadastro Gerais</title>
</head>

<body>
    <div class="container text-center" style="
    background-color: rgba(255, 255, 255, 0.4);
    backdrop-filter: blur(40px);
    padding: 30px 40px;
    width: 800px;
    border-radius: 20px;
    margin-top: 10vw;
    margin-bottom: 16vw;
    ">
        <h1>Cadastros Gerais</h1>
        <br><br>
        <a href="unidades/unidades.php"><button type="button" class="btn btn-primary">Cadastrar Unidades</button></a>
        <br><br>

    <div class="container text-center">
        <div class="row">
            <div class="col">
                <div class="dropdown">
                    <button class="btn btn-warning dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Cadastrar Pessoas
                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="cadastro_atleta.php?tipo=atleta">Atleta</a></li>
                        <li><a class="dropdown-item" href="cadastro_pessoa.php?tipo=chefe">Chefe de Delegação</a></li>
                        <li><a class="dropdown-item" href="cadastro_pessoa.php?tipo=outros">Outros</a></li>
                    </ul>
                </div>
            </div>
               
            <div class="col">
                <a class="btn btn-warning" href="pessoas/lista_pessoas.php"> Gerenciamento de Pessoas </a>
            </div>
        </div>
    </div>
    <br>
        <div class="dropdown">
            <button class="btn btn-danger dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                Cadastrar Campeonato
            </button>
            <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="cadastrar_torneio/cadastrar_torneio.php">Nome e Ano do Campeonato</a></li>
                <li><a class="dropdown-item" href="cadastro_atletasEquipe.php">Atletas nas Equipes</a></li>
                <li><a class="dropdown-item" href="cadastrar_equipe.php">Equipes do Campeonato</a></li>
                <li><a class="dropdown-item" href="cadastro_partida.php">Partidas do Campeonato</a></li>
                <li><a class="dropdown-item" href="cadastro_partida_rapido.php">Partidas Rápidas do Campeonato</a></li>
            </ul>
        </div>

    </div>

</body>

</html>