<?php
include('config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obtenha os dados do formulário
   
    $id_equipe1 = $_POST['nome_equipe1'];
    $id_equipe2 = $_POST['nome_equipe2'];
    $id_campeonato = $_POST['nome_campeonato'];
    $data_partida = $_POST['data_partida'];
    $resultado_equipe1 = $_POST['resultado_equipe1'];
    $resultado_equipe2 = $_POST['resultado_equipe2'];
    
    // Obtenha o próximo valor único para 'id_partida'
    $sql = "SELECT MAX(id_partida) AS max_id FROM cadastro_partida_rapida";
    $result = $conexao->query($sql);
    $row = $result->fetch_assoc();
    $next_id = $row['max_id'] + 1;

    // Inserir os dados na tabela 'partida' com o novo 'id_partida'
    $sql_insert = "INSERT INTO cadastro_partida_rapida (id_partida, id_equipe1, id_equipe2, id_campeonato, data_partida, resultado_equipe1, resultado_equipe2) VALUES ('$next_id', '$id_equipe1', '$id_equipe2','$id_campeonato', '$data_partida', '$resultado_equipe1', '$resultado_equipe2' )";

    if ($conexao->query($sql_insert) === TRUE) {
        // Inserção bem-sucedida
        $response = array('success' => true, 'message' => 'Dados Inseridos com Sucesso.');
    } else {
        // Erro na inserção
        $response = array('success' => false, 'message' => 'Erro ao inserir dados: ' . $conexao->error);
    }

    echo json_encode($response);
    exit();
    
}

$conexao->close();
?>

