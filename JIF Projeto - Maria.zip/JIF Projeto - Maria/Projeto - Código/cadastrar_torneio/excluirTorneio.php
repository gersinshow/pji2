<?php
include('config.php');

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Obtém o ID do torneio a ser excluído
if (isset($_POST['id_campeonato'])) {
    $id_campeonato = $_POST['id_campeonato'];
} else {
    http_response_code(400);
    echo json_encode(array('mensagem' => 'ID do torneio não fornecido.'));
    exit;
}

// Inicia uma transação para garantir consistência
$conexao->begin_transaction();

try {
    // Tentar excluir registros relacionados na tabela equipe_atleta
    $sqlExcluirEquipeAtleta = "DELETE FROM equipe_atleta WHERE id_campeonato = ?";
    $stmtExcluirEquipeAtleta = $conexao->prepare($sqlExcluirEquipeAtleta);
    $stmtExcluirEquipeAtleta->bind_param('i', $id_campeonato);
    $stmtExcluirEquipeAtleta->execute();

    // Tentar excluir registros relacionados na tabela equipe_delegacao
    $sqlExcluirEquipeDelegacao = "DELETE FROM equipe_delegacao WHERE id_campeonato = ?";
    $stmtExcluirEquipeDelegacao = $conexao->prepare($sqlExcluirEquipeDelegacao);
    $stmtExcluirEquipeDelegacao->bind_param('i', $id_campeonato);
    $stmtExcluirEquipeDelegacao->execute();

    // Tentar excluir registros relacionados na tabela equipe
    $sqlExcluirEquipe = "DELETE FROM equipe WHERE id_campeonato = ?";
    $stmtExcluirEquipe = $conexao->prepare($sqlExcluirEquipe);
    $stmtExcluirEquipe->bind_param('i', $id_campeonato);
    $stmtExcluirEquipe->execute();

    // Tentar excluir o torneio da tabela campeonato
    $sqlExcluirTorneio = "DELETE FROM campeonato WHERE id_campeonato = ?";
    $stmtExcluirTorneio = $conexao->prepare($sqlExcluirTorneio);
    $stmtExcluirTorneio->bind_param('i', $id_campeonato);
    $stmtExcluirTorneio->execute();

    // Comita a transação se tudo ocorrer sem erros
    $conexao->commit();

    // Responde com uma mensagem de sucesso em formato JSON
    echo json_encode(array('mensagem' => 'Torneio excluído com sucesso.'));
} catch (mysqli_sql_exception $e) {
    // Lidar com a exceção do MySQLi
    error_log('Erro MySQLi: ' . $e->getMessage());

    // Verificar se o erro é devido a violação de chave estrangeira
    if (strpos($e->getMessage(), 'Cannot delete or update a parent row') !== false) {
        http_response_code(400);
        echo json_encode(array('mensagem' => 'Erro ao excluir torneio. Existem dados associados em outras tabelas.'));
    } else {
        http_response_code(500);
        echo json_encode(array('mensagem' => 'Erro MySQLi ao excluir torneio.', 'erro' => $e->getMessage()));
    }
} finally {
    // Fecha a conexão com o banco de dados
    $conexao->close();
}
?>
