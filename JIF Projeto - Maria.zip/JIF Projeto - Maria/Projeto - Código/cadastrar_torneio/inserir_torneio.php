<?php
include('config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $titulo = $_POST['titulo'];
    $ano = $_POST['ano'];

    $sql = "SELECT MAX(id_campeonato) AS max_id FROM campeonato";
    $result = $conexao->query($sql);
    $row = $result->fetch_assoc();
    $next_id = $row['max_id'] + 1;

    $sql = "INSERT INTO campeonato (id_campeonato, ano, titulo) VALUES ('$next_id', '$ano', '$titulo')";

    if ($conexao->query($sql) === TRUE) {
        // Inserção bem-sucedida
        $response = array('success' => true, 'message' => 'Dados Inseridos com Sucesso.');
    } else {
        // Erro na inserção
        $response = array('success' => false, 'message' => 'Erro ao inserir dados: ' . $conexao->error);
    }

    echo json_encode($response);
    exit();
}

$conexao->close();
?>
