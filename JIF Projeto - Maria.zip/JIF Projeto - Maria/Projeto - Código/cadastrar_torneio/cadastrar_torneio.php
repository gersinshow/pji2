<?php
session_start();

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: login.php");
    exit();
}

include('config.php');

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css_2/style_atleta.css">
    <link rel="shortcut icon" href="../img/Logo.ico">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <title>Cadastro de Torneio</title>
</head>
<style>
    .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .back-button {
        padding: 5px 10px;
        text-decoration: none;
        background-color: green; 
        border: none;
        border-radius: 20px;
        color: white;
        cursor: pointer;
        font-size: 16px;
        transition: all 0.4s ease;
    }

    .back-button:hover {
        background-color: darkgreen; 
    }

    .formulario-boxzinha{
    background-color: rgba(255, 255, 255, 0.4);
    backdrop-filter: blur(40px);
    padding: 40px;
    width: 650px;
    border-radius: 20px;
    margin: 0 auto;
}
</style>

<body>
    <div class="boxzinha">
        <div class="formulario-boxzinha">
            <div class="header">
                <h2>Gerenciamento de Torneios</h2>
                <a class="back-button" href="../cadastros-gerais.php">Voltar</a>
            </div>

            <form  class="needs-validation" novalidate method="post">
                <div class="inputszinha">
                    <label for="titulo">Título do torneio</label>
                    <input type="text" class="form-control" id="titulo" name="titulo" placeholder="Digite o Título do Torneio" required>
                </div>

                <div class="inputszinha">
                    <label for="ano">Ano para contemplar o JIF</label>
                    <input type="text" class="form-control" id="ano" name="ano" placeholder="Exemplo: 2024" required>
                </div>

                <br>

                <div class="inputszinha">
                    <button type="submit">Inserir Torneio</button>
                </div>
            </form>

            <br><br>

            <h2>Lista de Torneios</h2>
            <br>
            
            <table class="table">
                <thead class="table-dark" id = "tableHeader">
                    


                </thead>
                <tbody id="torneioTableBody">
                    <!-- A tabela será preenchida dinamicamente com JavaScript -->

                </tbody>
            </table>
            
        </div>
    </div>

    <!-- Modal de Edição -->
    <div class="modal fade" id="editarModal" tabindex="-1" role="dialog" aria-labelledby="editarModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editarModalLabel">Editar Torneio</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <label for="editTitulo">Título do Torneio</label>
                    <input type="text" class="form-control" id="editTitulo" name="editTitulo" required>
                    <br><br>
                    <label for="editAnoTorneio">Ano</label>
                    <input type="text" class="form-control" id="editAnoTorneio" name="editAnoTorneio" required>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                    <button type="button" class="btn btn-primary" id="btnSalvar">Salvar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal de Confirmação de Exclusão -->
    <div class="modal fade" id="confirmDeleteModal" tabindex="-1" role="dialog" aria-labelledby="confirmDeleteModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="confirmDeleteModalLabel">Confirmar Exclusão</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Deseja realmente excluir este Torneio?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-danger" id="confirmDeleteBtn">Excluir</button>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>

    <!-- Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>



    <script>
    var idTorneioEditando = null;

    $(document).ready(function () {

        // Adicione um manipulador de eventos para o envio do formulário
        $('form').submit(function (e) {
            e.preventDefault(); // Evite o envio padrão do formulário

            // Obtenha os dados do formulário
            var titulo = $('#titulo').val();
            var ano = $('#ano').val();

            // Enviar dados via AJAX
            $.ajax({
                url: 'inserir_torneio.php',
                type: 'POST',
                data: {
                    titulo: titulo,
                    ano: ano
                },
                dataType: 'json',
                success: function (response) {
                    // Lógica de tratamento após inserção bem-sucedida
                    if (response.success) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Sucesso',
                            text: response.message,
                            showConfirmButton: false,
                            timer: 1500
                        });

                        $('#titulo').val('');
                        $('#ano').val('');

                        // Recarregue a tabela de torneios
                        carregarTorneios();
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Erro',
                            text: response.message,
                            showConfirmButton: false,
                            timer: 1500
                        });
                    }
                },
                error: function (xhr, status, error) {
                    console.error(xhr.responseText);
                    // Lógica de tratamento de erro, se necessário
                    Swal.fire({
                        icon: 'error',
                        title: 'Erro',
                        text: 'Erro ao processar a solicitação.',
                        showConfirmButton: false,
                        timer: 1500
                    });
                }
            });
        });

        // Função para carregar pessoas com base no tipo selecionado
        window.carregarTorneios = function () {
            $.ajax({
                url: 'carregarTorneios.php',
                type: 'POST',
                data: {},
                dataType: 'json',
                success: function (data) {
                    console.log(data);
                    // Limpa a tabela antes de preenchê-la
                    $('#torneioTableBody').empty();

                    if (data.length > 0) {
                        construirCabecalho();
                        preencherTabela(data);
                    } else {
                        // Se não houver torneios, exibe a mensagem "Nenhum Torneio Foi Inserido Ainda"
                        $('#tableHeader').empty();
                        $('#torneioTableBody').html('<p> Nenhum Torneio Foi Inserido Ainda</p>');
                    }
                },
                error: function (xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        };

        // Função para construir o cabeçalho da tabela
        function construirCabecalho() {
            var header = '<tr>' +
                '<th scope="col" class="text-center">ID</th>' +
                '<th scope="col" class="text-center">Ano</th>' +
                '<th scope="col" class="text-center">Título</th>' +
                '<th scope="col" class="text-center">Editar</th>' +
                '<th scope="col" class="text-center">Excluir</th>' +
                '</tr>';
            $('#tableHeader').html(header);
        }

        // Função para preencher a tabela com dados
        function preencherTabela(data) {
            $.each(data, function (index, campeonato) {
                var row = '<tr>' +
                    '<td class="text-center">' + campeonato.id_campeonato + '</td>' +
                    '<td class="text-center">' + campeonato.ano + '</td>' +
                    '<td class="text-center">' + campeonato.titulo + '</td>' +
                    '<td class="text-center"><button class="btn btn-primary" data-id="' + campeonato.id_campeonato + '" onclick="abrirModalEditar(' + campeonato.id_campeonato + ')">Editar</button></td>' +
                    '<td class="text-center"><button class="btn btn-danger" data-id="' + campeonato.id_campeonato + '" onclick="confirmarExclusao(' + campeonato.id_campeonato + ')">Excluir</button></td>' +
                    '</tr>';
                $('#torneioTableBody').append(row);
            });
        }


        window.abrirModalEditar = function (idTorneio) {
            // Adaptação para obter o tipo de pessoa correspondente
            $.ajax({
                url: 'getTorneioById.php',
                type: 'POST',
                data: { idTorneio: idTorneio },
                dataType: 'json',
                success: function (data) {
                    console.log('Dados do Torneio:', data);
                    console.log('idTorneio:', idTorneio);

                    if (data) {
                        // Lógica para preencher os campos do modal com os dados do torneio
                        $('#editTitulo').val(data.titulo);
                        $('#editAnoTorneio').val(data.ano);

                        // Define o idTorneioEditando global
                        idTorneioEditando = idTorneio;

                        // Abre o modal
                        $('#editarModal').modal('show');
                    } else {
                        console.error('Torneio não encontrado.');
                    }
                },
                error: function (xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        };

        carregarTorneios();

        function abrirModalEditar(idTorneio) {
            console.log('Abrindo modal para idTorneio:', idTorneio);

            $.ajax({
                url: 'getTorneioById.php', 
                type: 'POST',
                data: { idTorneio: idTorneio },
                dataType: 'json',
                success: function (data) {
                    console.log('Dados do Torneio:', data);
                    console.log('idTorneio:', idTorneio);

                    // Lógica para preencher os campos do modal com os dados do torneio
                    $('#editTitulo').val(data.titulo);
                    $('#editAnoTorneio').val(data.ano);

                    // Abre o modal 
                    $('#editarModal').modal('show');
                }
            });

            idTorneioEditando = null;
        }
        
        function salvarTorneio() {
            var titulo = $('#editTitulo').val();
            var ano = $('#editAnoTorneio').val();

            $.ajax({
                url: 'salvarTorneio.php',
                type: 'POST',
                data: {
                    idTorneio: idTorneioEditando,
                    titulo: titulo,
                    ano: ano
                },
                success: function (response) {
                    console.log(response);
                    // Lógica de tratamento após salvar os dados da pessoa comum
                    Swal.fire({
                        icon: 'success',
                        title: 'Torneio salvo com sucesso!',
                        showConfirmButton: false,
                        timer: 1500  // Fecha automaticamente após 1.5 segundos
                    });

                    // Fecha o modal genérico
                    $('#editarModal').modal('hide');

                    carregarTorneios();
                },
                error: function (xhr, status, error) {
                    console.error(xhr.responseText);
                    // Lógica de tratamento de erro, se necessário
                }
            });

            idTorneioEditando = null;
        }

        // Adicione um parâmetro para receber o idTorneio na função confirmarExclusao
        window.confirmarExclusao = function (idTorneio) {
            console.log('ID do Torneio a ser excluído:', idTorneio);
            $('#confirmDeleteModal').modal('show');

            // Define a função de confirmação de exclusão no botão de confirmação
            $('#confirmDeleteBtn').off('click').on('click', function () {
                // AJAX para excluir o torneio do banco de dados
                $.ajax({
                    url: 'excluirTorneio.php',
                    type: 'POST',
                    data: { id_campeonato: idTorneio },
                    success: function (response) {
                        console.log(response);
                        // Fecha o modal de confirmação de exclusão
                        $('#confirmDeleteModal').modal('hide');

                        // Exibe uma mensagem de sucesso usando SweetAlert2
                        Swal.fire({
                            icon: 'success',
                            title: 'Torneio excluído com sucesso!',
                            showConfirmButton: false,
                            timer: 1500  // Fecha automaticamente após 1.5 segundos
                        });

                        // Recarrega a lista de torneios após excluir
                        carregarTorneios();
                    },
                    error: function (xhr, status, error) {
                        //console.error(xhr.responseText);

                        // Adicione o alerta de erro do SweetAlert2
                        Swal.fire({
                            icon: 'error',
                            title: 'Erro ao excluir torneio',
                            text: 'Ocorreu um erro ao excluir o torneio. Verifique se não existem dados associados em outras tabelas.',
                            footer: 'Exclua os dados correspondentes para efetuar a exclusão.'
                        });

                        $('#confirmDeleteModal').modal('hide');
                    }
                });
            });
        };


        // Adicione a lógica para o botão Salvar no modal genérico
        $('#btnSalvar').on('click', function () {
            salvarTorneio();
        });

        // Adicione um manipulador de eventos para o clique no botão "Editar"
        $('#torneioTableBody').on('click', '.btn-primary', function() {
            // Obtenha o idTorneio da linha da tabela
            var idTorneio = $(this).closest('tr').find('.btn-primary').data('id');
            
            // Chame abrirModalEditar passando o idTorneio
            abrirModalEditar(idTorneio);
        });
    });
    </script>


</body>

</html>

