<?php
include('config.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Obtenha os dados da solicitação POST
        var_dump($_POST);
        $id_campeonato = isset($_POST['nomeCampeonato']) ? $_POST['nomeCampeonato'] : null;
        $data_partida = isset($_POST['dataPartida']) ? $_POST['dataPartida'] : null;
        $id_equipe1 = isset($_POST['nomeEquipe1']) ? $_POST['nomeEquipe1'] : null;
        $resultado_equipe1 = isset($_POST['resultadoEquipe1']) ? $_POST['resultadoEquipe1'] : null;
        $id_equipe2 = isset($_POST['nomeEquipe2']) ? $_POST['nomeEquipe2'] : null;
        $resultado_equipe2 = isset($_POST['resultadoEquipe2']) ? $_POST['resultadoEquipe2'] : null;

        $id_partida = $conexao->real_escape_string($_POST['idPartida']);

        // Inicie uma transação
        $conexao->begin_transaction();

        // Verifique se é uma atualização ou inserção
        if ($id_partida) {
            // Já existe um registro, então atualiza
            $sqlUpdate = "UPDATE cadastro_partida_rapida SET data_partida=?, resultado_equipe1=?, resultado_equipe2=? WHERE id_partida=?";
            $stmtUpdate = $conexao->prepare($sqlUpdate);
            $stmtUpdate->bind_param("siii", $data_partida, $resultado_equipe1, $resultado_equipe2, $id_partida);
            $stmtUpdate->execute();

            // Verifica se ocorreu um erro na atualização
            if ($stmtUpdate->errno !== 0) {
                throw new Exception('Erro ao atualizar partida: ' . $stmtUpdate->error);
            }

            // Responda com sucesso
            $conexao->commit();
            echo json_encode(array('mensagem' => 'Partida atualizada com sucesso.'));
        } else {
            // Não existe um registro, então insere
            $sqlInsert = "INSERT INTO cadastro_partida_rapida (data_partida, resultado_equipe1, resultado_equipe2) VALUES (?, ?, ?, ?, ?, ?)";
            $stmtInsert = $conexao->prepare($sqlInsert);
            $stmtInsert->bind_param("sii", $data_partida, $resultado_equipe1, $resultado_equipe2);
            $stmtInsert->execute();

            // Verifica se ocorreu um erro na inserção
            if ($stmtInsert->errno !== 0) {
                throw new Exception('Erro ao inserir partida: ' . $stmtInsert->error);
            }

            // Responda com sucesso
            $conexao->commit();
            echo json_encode(array('mensagem' => 'Partida salva com sucesso.'));
        }
    } catch (Exception $e) {
        // Se ocorrer uma exceção, faça o rollback da transação e retorne o erro
        $conexao->rollback();

        // Adicione a mensagem de erro ao retorno JSON para depuração
        echo json_encode(array('mensagem' => 'Erro: ' . $e->getMessage()));

        // Retorne um cabeçalho 500 Internal Server Error
        http_response_code(500);
    }
} else {
    // Retornar algum erro se a requisição não for do tipo POST
    http_response_code(400);
    echo json_encode(array('mensagem' => 'Erro na requisição.'));
}
?>
