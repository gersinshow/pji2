<?php
// salvarTorneio.php

include('config.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Obtenha os dados da solicitação POST
        $titulo = $_POST['titulo'];
        $ano = $_POST['ano'];

        // Verifique se os dados foram recebidos corretamente (depuração)
        // Isso pode ser removido em um ambiente de produção
        echo 'Dados Recebidos: Título - ' . $titulo . ', Ano - ' . $ano;

        // Inicie uma transação
        $conexao->begin_transaction();

        $id_campeonato = $conexao->real_escape_string($_POST['idTorneio']);
        // Verifique se é uma atualização ou inserção
        
        if ($id_campeonato) {
            // Já existe um registro, então atualiza
            $sqlUpdate = "UPDATE campeonato SET titulo=?, ano=? WHERE id_campeonato=?";
            $stmtUpdate = $conexao->prepare($sqlUpdate);
            $stmtUpdate->bind_param("ssi", $titulo, $ano, $id_campeonato);
            $stmtUpdate->execute();

            // Verifica se ocorreu um erro na atualização
            if ($stmtUpdate->errno !== 0) {
                throw new Exception('Erro ao atualizar torneio: ' . $stmtUpdate->error);
            }

            // Responda com sucesso
            $conexao->commit();
            echo json_encode(array('mensagem' => 'Torneio atualizado com sucesso.'));
        } else {
            // Não existe um registro, então insere
            $sqlInsert = "INSERT INTO campeonato (titulo, ano) VALUES (?, ?)";
            $stmtInsert = $conexao->prepare($sqlInsert);
            $stmtInsert->bind_param("si", $titulo, $ano);
            $stmtInsert->execute();

            // Verifica se ocorreu um erro na inserção
            if ($stmtInsert->errno !== 0) {
                throw new Exception('Erro ao inserir torneio: ' . $stmtInsert->error);
            }

            // Responda com sucesso
            $conexao->commit();
            echo json_encode(array('mensagem' => 'Torneio salvo com sucesso.'));
        }
    } catch (Exception $e) {
        // Se ocorrer uma exceção, faça o rollback da transação e retorne o erro
        $conexao->rollback();

        // Adicione a mensagem de erro ao retorno JSON para depuração
        echo json_encode(array('mensagem' => 'Erro: ' . $e->getMessage()));

        // Retorne um cabeçalho 500 Internal Server Error
        http_response_code(500);
    }
} else {
    // Retornar algum erro se a requisição não for do tipo POST
    http_response_code(400);
    echo json_encode(array('mensagem' => 'Erro na requisição.'));
}
?>
