<?php
session_start();

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: login.php");
    exit();
}


$currentPage = isset($_GET['page']) ? $_GET['page'] : 2;
$previousPage = $currentPage - 1;
$nextPage = $currentPage + 1;
?>

<?php

include('config.php');

$successMessage = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
// Obtenha os dados do formulário
$titulo = $_POST['titulo'];
$ano = $_POST['ano_torneio'];

// Obtenha o próximo valor único para 'id_unidade'
$sql = "SELECT MAX(id_campeonato) AS max_id FROM campeonato";
$result = $conexao->query($sql);
$row = $result->fetch_assoc();
$next_id = $row['max_id'] + 1;

// Inserir os dados na tabela 'unidade' com o novo 'id_unidade'
$sql = "INSERT INTO campeonato (id_campeonato, ano, titulo) VALUES ('$next_id', '$ano', '$titulo')";

if ($conexao->query($sql) === TRUE) {
$_SESSION['successMessage'] = "Dados Inseridos com Sucesso.";
}
}

// Feche a conexão com o banco de dados
$conexao->close();

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css_2/style.css">
    <link rel="shortcut icon" href="img/Logo.ico">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <title>Cadastro de Torneio</title>
</head>
<style>
    .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .back-button {
        padding: 5px 10px;
        text-decoration: none;
        background-color: green; 
        border: none;
        border-radius: 20px;
        color: white;
        cursor: pointer;
        font-size: 16px;
        transition: all 0.4s ease;
    }

    .back-button:hover {
        background-color: darkgreen; 
    }
</style>

<body>
    <div class="boxzinha">
        <div class="img-boxzinha">
            <img src="css_2/img-formulario.png">
        </div>
        <div class="formulario-boxzinha">
            <div class="header">
                <h2>Cadastro de Torneio</h2>
                <a class="back-button" href="cadastros-gerais.php">Voltar</a>
            </div>

            <form  action="cadastrar_torneio.php"class="needs-validation" novalidate method="post">
            <div class="inputszinha">
                <label for="titulo">Título do torneio</label>
                <input type="text" class="form-control" id="titulo" name="titulo" placeholder="Digite o Título do Torneio" required>
            </div>

            <div class="inputszinha">
                <label for="ano_torneio">Ano para contemplar o JIF</label>
                <input type="text" class="form-control" id="ano_torneio" name="ano_torneio" placeholder="Exemplo: 2024" required>
            </div>

            <br>

                <div class="inputszinha">
                    <button>Criar Torneio</button>
                </div>
            </form>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>

</html>

