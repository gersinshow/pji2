<?php
// getAtletaById.php

include('config.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {


    // Verifique a conexão
    if ($conexao->connect_error) {
        die("Conexão falhou: " . $conexao->connect_error);
    }

    // Evite SQL Injection escapando os parâmetros
    $idPessoa = $conexao->real_escape_string($_POST['idPessoa']);

    // Lógica para obter os detalhes do atleta do banco de dados pelo ID
    // Substitua os campos e tabelas de acordo com a sua estrutura de banco de dados
    $sql = "SELECT * FROM pessoa WHERE tipo_pessoa_id = '$idPessoa'";
    $result = $conexao->query($sql);

    // Verifique se há resultados
    if ($result->num_rows > 0) {
        // Converta os resultados em um array associativo
        $atleta = $result->fetch_assoc();

        // Libere os resultados e feche a conexão
        $result->close();
        $conexao->close();

        // Retorne o array associativo como JSON
        echo json_encode($atleta);
    } else {
        // Se não houver resultados, retorne um array vazio como JSON
        echo json_encode(array());
    }
} else {
    // Retornar algum erro se a requisição não for do tipo POST
    http_response_code(400);
    echo json_encode(array('mensagem' => 'Erro na requisição.'));
}
?>
