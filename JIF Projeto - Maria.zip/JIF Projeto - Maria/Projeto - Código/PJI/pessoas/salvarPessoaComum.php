<?php
// salvarPessoaComum.php

include('config.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Obtenha os dados da solicitação POST
        $nome = $_POST['nome'];
        $cpf = $_POST['cpf'];
        $datanasc = $_POST['datanasc'];
        $sexo = $_POST['sexo'];

        // Inicie uma transação
        $conexao->begin_transaction();

        // Verifique se é uma atualização ou inserção
        if ($cpf) {
            // Buscar tipoPessoaId do banco de dados
            $sqlTipoPessoa = "SELECT id_tipo FROM pessoa_tipo WHERE cpf_pessoa = ?";
            $stmtTipoPessoa = $conexao->prepare($sqlTipoPessoa);
            $stmtTipoPessoa->bind_param("s", $cpf);
            $stmtTipoPessoa->execute();
            $resultTipoPessoa = $stmtTipoPessoa->get_result();

            if ($resultTipoPessoa->num_rows > 0) {
                // Já existe um registro, então atualiza
                $tipoPessoa = $resultTipoPessoa->fetch_assoc();
                $tipoPessoaId = $tipoPessoa['id_tipo'];

                $sqlUpdate = "UPDATE pessoa SET nome=?, datanasc=?, sexo=? WHERE cpf=?";
                $stmtUpdate = $conexao->prepare($sqlUpdate);
                $stmtUpdate->bind_param("ssss", $nome, $datanasc, $sexo, $cpf);
                $stmtUpdate->execute();

                // Verifica se ocorreu um erro na atualização
                if ($stmtUpdate->errno !== 0) {
                    throw new Exception('Erro ao atualizar pessoa: ' . $stmtUpdate->error);
                }

                // Responda com sucesso
                $conexao->commit();
                echo json_encode(array('mensagem' => 'Pessoa atualizada com sucesso.'));
            } else {
                // Não existe um registro, então insere
                $tipoPessoaId = 1; // Defina o valor adequado para o tipo de pessoa comum
                $sqlInsert = "INSERT INTO pessoa_tipo (cpf_pessoa, id_tipo) VALUES (?, ?)";
                $stmtInsert = $conexao->prepare($sqlInsert);
                $stmtInsert->bind_param("si", $cpf, $tipoPessoaId);
                $stmtInsert->execute();

                // Verifica se ocorreu um erro na inserção
                if ($stmtInsert->errno !== 0) {
                    throw new Exception('Erro ao inserir pessoa_tipo: ' . $stmtInsert->error);
                }

                // Responda com sucesso
                $conexao->commit();
                echo json_encode(array('mensagem' => 'Pessoa salva com sucesso.'));
            }
        } else {
            // Retornar algum erro se o CPF não estiver presente
            throw new Exception('Erro: CPF não fornecido.');
        }
    } catch (Exception $e) {
        // Se ocorrer uma exceção, faça o rollback da transação e retorne o erro
        $conexao->rollback();
        http_response_code(500);
        echo json_encode(array('mensagem' => $e->getMessage()));
    }
} else {
    // Retornar algum erro se a requisição não for do tipo POST
    http_response_code(400);
    echo json_encode(array('mensagem' => 'Erro na requisição.'));
}
?>
