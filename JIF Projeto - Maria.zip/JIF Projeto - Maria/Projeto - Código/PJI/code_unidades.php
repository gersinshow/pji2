<?php

header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

session_start();
include('config.php');
$messages = array();

if (isset($_POST['edit_data_btn'])) {
    getUnidadeForEdit();
    exit();
}

if (isset($_POST['update_data'])) {
    updateUnidade();
    exit();
}

if (isset($_GET['action']) && $_GET['action'] == 'updateTable') {
    updateTable();
    exit();
}

if(isset($_POST['confirm_delete_btn']))
{
    confirmDeleteUnidade();
    exit();
}

function getUnidadeForEdit()
{
    global $conexao;

    $id = $_POST['user_id'];
    $arrayresult = [];

    $fetch_query = "SELECT * FROM unidade WHERE id_unidade = '$id'";
    $fetch_query_run = mysqli_query($conexao, $fetch_query);

    if ($fetch_query_run) {
        if (mysqli_num_rows($fetch_query_run) > 0) {
            while ($row = mysqli_fetch_array($fetch_query_run)) {
                $arrayresult[] = $row;
            }

            header('Content-Type: application/json');
            echo json_encode($arrayresult);
        } else {
            header('Content-Type: application/json');
            echo json_encode(['error' => 'Não foi encontrado nenhum registro.']);
        }
    } else {
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Erro ao executar a consulta: ' . mysqli_error($conexao)]);
    }
}

function updateUnidade()
{
    global $conexao, $messages;

    $user_id = $_POST['user_id'];
    $editSigla = $_POST['editSigla'];
    $editCampus = $_POST['editCampus'];

    $sql = "UPDATE unidade SET sigla_instituicao = '$editSigla', campus = '$editCampus' WHERE id_unidade = $user_id";

    if ($conexao->query($sql) === TRUE) {
        $_SESSION['messages']['success'][] = "Unidade Atualizada com Sucesso!";
      
        echo json_encode(['success' => 'Unidade Atualizada com Sucesso!']);
    } else {
        $_SESSION['messages']['error'][] = "Erro ao Atualizar a unidade. Tente novamente.";
      
        echo json_encode(['error' => 'Erro ao Atualizar a unidade. Tente novamente.']);
    }

}

function updateTable()
{
    global $conexao;

    $sql = "SELECT * FROM unidade";
    $result = $conexao->query($sql);

    if ($result !== false && $result->num_rows > 0) {
        $data = array();
    
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    
        echo json_encode(['status' => 'success', 'data' => $data]);
    } else {
        echo json_encode(['status' => 'empty', 'data' => []]);
    }
}


function confirmDeleteUnidade()
{
    global $conexao, $messages;

    $id = $_POST['confirm_user_id'];

    $delete_query = "DELETE FROM unidade WHERE id_unidade='$id'";
    $delete_query_run = mysqli_query($conexao, $delete_query);

    if ($delete_query_run) {
        $_SESSION['messages']['success'][] = "Unidade Excluída com Sucesso!";
        
        echo json_encode(['success' => 'Unidade Excluída com Sucesso!']);
        
    } else {
        $_SESSION['messages']['error'][] = "Erro ao Excluir a Unidade. Tente novamente.";
       
        echo json_encode(['error' => 'Erro ao Excluir a Unidade. Tente novamente.']);
    }
   
}

?>
