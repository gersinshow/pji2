<?php
session_start();

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: login.php");
    exit();
}

include('config.php');

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="css_2/style_atleta.css">
    <link rel="shortcut icon" href="img/Logo.ico">
    <title>Cadastro de Unidades</title>

</head>
<style>
    .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .back-button {
        padding: 5px 10px;
        text-decoration: none;
        background-color: green; 
        border: none;
        border-radius: 20px;
        color: white;
        cursor: pointer;
        font-size: 16px;
        transition: all 0.4s ease;
    }

    .back-button:hover {
        background-color: darkgreen; 
    } 

</style>

<body>
    
    <div class="boxzinha">

        <div class="formulario-boxzinha">
            <div class="header">
                <h2>Unidades</h2>
                <a class="back-button" href="cadastros-gerais.php">Voltar</a>
            </div>
            
            <form action="unidades/cadastrar_unidade.php" method="POST" id="cad-usuario-form">
                <div class="inputszinha">
                    <label for="sigla"> Sigla da Instituição</label>
                    <input type="text" id="sigla" name="sigla" placeholder="Digite a Sigla (IFSP)" required>
                </div>

                <div class="inputszinha">
                    <label for="campus">Câmpus</label>
                    <input type="text" id="campus" name="campus" placeholder="Digite seu Câmpus (Araraquara)" required>
                </div>
            
                <div class="inputszinha">
                    <button type="submit" name = "save" id="cadastrar-button">Inserir Unidade</button>
                </div>
                <br>
                
            </form>

            <h2>Lista de Unidades</h2>
            <br>
            <?php
                // Consulta ao banco de dados e exibição da tabela
                $sql = "SELECT * FROM unidade";
                $result = $conexao->query($sql);

                echo '<table class="table" id="tabelaUnidades">';
                echo '<thead class="table-light">';
                echo '<tr>';
                echo '<th scope="col" class="text-center">ID</th>';
                echo '<th scope="col" class="text-center">Sigla Instituição</th>';
                echo '<th scope="col" class="text-center">Campus</th>';
                echo '<th scope="col" class="text-center">Editar</th>';
                echo '<th scope="col" class="text-center">Excluir</th>';
                echo '</tr>';
                echo '</thead>';
                echo '<tbody>';

                if ($result !== false && $result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo '<tr>';
                        echo '<td class="text-center user_id">' . $row['id_unidade'] . '</td>';
                        echo '<td class="text-center">' . $row['sigla_instituicao'] . '</td>';
                        echo '<td class="text-center">' . $row['campus'] . '</td>';
                        echo '<td class="text-center">';
                        echo '<a href="#" class="btn btn-primary edit_data"> Editar </a>';
                        echo '</td>';
                        echo '<td class="text-center">';
                        echo '<a href="#" class="btn btn-danger confirm_delete_data" > Excluir </a>';
                        echo '</td>';
                        echo '</tr>';
                    }
                } else {
                    echo '<tr><td colspan="5" class="text-center">Nenhuma unidade encontrada.</td></tr>';
                    if ($result === false) {
                        echo '<tr><td colspan="5" class="text-center">Erro na consulta: ' . $conexao->error . '</td></tr>';
                    }
                }

                echo '</tbody>';
                echo '</table>';
                ?>


        </div>
    </div>

    <!-- Modal de Edição -->
    <div class="modal fade" id="editarModal" tabindex="-1" role="dialog" aria-labelledby="editarModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editarModalLabel">Editar Unidade</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="user_id" name="id">
                    <label for="editSigla">Nova Sigla da Instituição:</label>
                    <input type="text" id="editSigla" name="editSigla" required>
                    <br><br>
                    <label for="editCampus">Novo Câmpus:</label>
                    <input type="text" id="editCampus" name="editCampus" required>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                    <button type="button" class="btn btn-primary" id="btnSalvar">Salvar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal de Confirmação de Exclusão -->
    <div class="modal fade" id="confirmDeleteModal" tabindex="-1" role="dialog" aria-labelledby="confirmDeleteModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="confirmDeleteModalLabel">Confirmar Exclusão</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Deseja realmente excluir esta unidade?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-danger" id="confirmDeleteBtn">Excluir</button>
                </div>
            </div>
        </div>
    </div>
   
<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>

<!-- Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

<!-- SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- Custom JS -->
<script src="js/custom.js"></script>

<script>

function updateTable() {
    console.log('Chamando updateTable... 1');
    $.ajax({
        method: "GET",
        url: "/unidades/code_unidades.php?action=updateTable",
        dataType: 'json',
        success: function (response) {
            console.log('Resposta da atualização:', response);
            if (response.status === 'success') {
                
                var data = response.data;

                if (Array.isArray(data) && data.length > 0) {
                    $('#tabelaUnidades tbody').empty();

                    $.each(data, function (index, row) {
                        var newRow = '<tr>' +
                            '<td class="text-center user_id">' + row['id_unidade'] + '</td>' +
                            '<td class="text-center">' + row['sigla_instituicao'] + '</td>' +
                            '<td class="text-center">' + row['campus'] + '</td>' +
                            '<td class="text-center">' +
                            '<a href="#" class="btn btn-primary edit_data"> Editar </a>' +
                            '</td>' +
                            '<td class="text-center">' +
                            '<a href="#" class="btn btn-danger confirm_delete_data" > Excluir </a>' +
                            '</td>' +
                            '</tr>';

                        $('#tabelaUnidades tbody').append(newRow);
                    });
                } else {
                    // Caso a tabela esteja vazia, exibir mensagem
                    $('#tabelaUnidades tbody').empty();
                    $('#tabelaUnidades tbody').append('<tr><td colspan="5" class="text-center">Nenhuma Unidade Foi Inserida Ainda</td></tr>');
                }
            } else if (response.status === 'empty') {
                // Caso a tabela esteja vazia, exibir mensagem
                $('#tabelaUnidades tbody').empty();
                $('#tabelaUnidades tbody').append('<tr><td colspan="5" class="text-center">Nenhuma Unidade Foi Inserida Ainda</td></tr>');
            } else if ('error' in response) {
                console.log('Error:', response.error);
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log('AJAX Error:', textStatus, errorThrown);
        }
    });
}




    $(document).ready(function () {

        var id;

        $(document).on('click', '.edit_data', function (e) {
            e.preventDefault();

            var user_id = $(this).closest('tr').find('.user_id').text();

            $.ajax({
                method: "POST",
                url: "/unidades/code_unidades.php",
                data: {
                    'edit_data_btn': true,
                    'user_id': user_id,
                },
                dataType: 'json',
                cache: false,
                success: function (response) {
                    try {
                        if ('error' in response) {
                            console.log('Error:', response.error);
                        } else {
                            id = response[0]['id_unidade'];
                            $('#user_id').val(id);
                            $('#editSigla').val(response[0]['sigla_instituicao']);
                            $('#editCampus').val(response[0]['campus']);
                            $('#editarModal').modal('show');

                            
                        }
                    } catch (e) {
                        console.error('Error parsing JSON:', e);
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    console.log('AJAX Error:', textStatus, errorThrown);
                }
            });
        });

        $('#btnSalvar').click(function () {
            var user_id = $('#user_id').val();
            var sigla = $('#editSigla').val();
            var campus = $('#editCampus').val();

            $.ajax({
                method: "POST",
                url: "/unidades/code_unidades.php",
                data: {
                    'update_data': true,
                    'user_id': user_id,
                    'editSigla': sigla,
                    'editCampus': campus
                },
                dataType: 'json',
                cache: false,
                success: function (response) {
                    if ('error' in response) {
                        //ALERTA AQUI
                        Swal.fire({
                            icon: "error",
                            title: "Oops...",
                            text: "Something went wrong!",
                            footer: '<a href="#">Why do I have this issue?</a>'
                        });
                       
                    } else {
                        //ALERTA AQUI
                        
                        Swal.fire({
                                text: "Unidade Atualizada com Sucesso!",
                                icon: 'success',
                                showCancelButton: false,
                                confirmButtonColor: '#3085d6',
                                confirmButtonText: 'Fechar'
                            });
                    
                        $('#editarModal').modal('hide');
                        
                        updateTable();
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    console.log('AJAX Error:', textStatus, errorThrown);
                }
            });
        });

        $(document).on('click', '.confirm_delete_data', function (e) {
            e.preventDefault();

            // Armazena o ID da unidade que será excluída
            var confirm_user_id = $(this).closest('tr').find('.user_id').text();

            // Exibe o modal de confirmação
            $('#confirmDeleteModal').modal('show');

            // Armazena o ID no botão de confirmação do modal
            $('#confirmDeleteBtn').data('confirm_user_id', confirm_user_id);

        });

        

        
        updateTable();
    });

    
    $('#confirmDeleteBtn').click(function () {
            // Fecha o modal de confirmação
            $('#confirmDeleteModal').modal('hide');

            // Obtém o ID da unidade do botão de confirmação
            var confirm_user_id = $(this).data('confirm_user_id');

            // Envia a solicitação de exclusão ao servidor
            $.ajax({
                method: "POST",
                url: "/unidades/code_unidades.php",
                data: {
                    'confirm_delete_btn': true,
                    'confirm_user_id': confirm_user_id,
                },
                dataType: 'json',
                success: function (response) {
                    try {
                        if (response.success !== undefined) {
                            
                            //ALERTA AQUI
                            Swal.fire({
                                text: "Unidade Excluída com Sucesso!",
                                icon: 'success',
                                showCancelButton: false,
                                confirmButtonColor: '#3085d6',
                                confirmButtonText: 'Fechar'
                            })
                            
                            updateTable();  // Adiciona esta linha para atualizar a tabela
                            
                            
                        } else if (response.error !== undefined) {
                            //ALERTA AQUI
                            Swal.fire({
                                icon: "error",
                                title: "Oops...",
                                text: "Existem dados em outras tabelas associados a essa unidade!",
                                footer: 'Exclua os dados correspondentes para efetuar a <strong>exclusão</strong>.'
                            });
                            
                        } else {
                            console.log('Resposta inesperada:', response);
                        }
                    } catch (e) {
                        console.error('Error parsing JSON:', e);
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    console.log('AJAX Error:', textStatus, errorThrown);
                }
            });
            updateTable();
        });
</script>

</body>

</html>
