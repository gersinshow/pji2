<?php
session_start();

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: login.php");
    exit();
}

include('config.php');

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="css_2/style_atleta.css">
    <link rel="shortcut icon" href="img/Logo.ico">
    <title>Lista de Pessoas</title>

</head>
<style>
    .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .back-button {
        padding: 5px 10px;
        text-decoration: none;
        background-color: green; 
        border: none;
        border-radius: 20px;
        color: white;
        cursor: pointer;
        font-size: 16px;
        transition: all 0.4s ease;
    }

    .back-button:hover {
        background-color: darkgreen; 
    } 

</style>

<body>
    
    <div class="boxzinha">

        <div class="formulario-boxzinha">
            <div class="header">
                <h2>Gerenciamento de Pessoas</h2>
                <a class="back-button" href="cadastros-gerais.php">Voltar</a>
            </div>
            
            <form action="#" method="POST" >
                <div class="inputszinha">
                    <label for="tipoSelect">Selecione o Tipo de Pessoa:</label>
                    <select id="tipoSelect" onchange="carregarPessoas()">
                        
                    </select>
                </div>

                
            </form>

            <h2>Lista de Pessoas</h2>
            <br>
            <?php
                // Consulta ao banco de dados e exibição da tabela
                
            ?>


        </div>
    </div>

    <!-- Modal de Edição Tipo: Chefe de Delegação e Outros -->
    <div class="modal fade" id="editarModal" tabindex="-1" role="dialog" aria-labelledby="editarModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editarModalLabel">Editar Pessoa</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="user_id" name="id">
                    <label for="editNome">Nome Completo</label>
                    <input type="text" id="editNome" name="editNome" required>
                    <br><br>
                    <label for="editCPF">CPF</label>
                    <input type="text" id="editCPF" name="editCPF" required>
                    <br><br>
                    <label for="editData">Data de Nascimento</label>
                    <input type="date" id="editData" name = "editData" required>
                    <br><br>
                    <label> Sexo: </label>
                    <div class="sexo">
                        <input type="radio" value="M" name="sexo"> Masculino <br>
                        <input type="radio" value="F" name="sexo"> Feminino <br>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                    <button type="button" class="btn btn-primary" id="btnSalvar">Salvar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal de Edição Tipo: Atleta -->
    <div class="modal fade" id="editarModal" tabindex="-1" role="dialog" aria-labelledby="editarModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editarModalLabel">Editar Atleta</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="user_id" name="id">
                    <label for="editResponsavel"> Nome Completo do Responsável </label>
                    <input type="text" id="editResponsavel" name="editResponsavel" required>
                    <label for="editNomeAtleta">Nome Completo</label>
                    <input type="text" id="editNomeAtleta" name="editNomeAtleta" required>
                    <br><br>
                    <label for="editCPFAtleta">CPF</label>
                    <input type="text" id="editCPFAtleta" name="editCPFAtleta" required>
                    <br><br>
                    <label for="editRGAtleta">RG</label>
                    <input type="text" id="editRGAtleta" name="editRGAtleta" required>
                    <label for="editRAAtleta">RA (Prontuário)</label>
                    <input type="text" id="editRAAtleta" name="editRAAtleta" required>
                    <label for="editDataAtleta">Data de Nascimento</label>
                    <input type="date" id="editDataAtleta" name = "editDataAtleta" required>
                    <br><br>
                    <label> Sexo: </label>
                    <div class="sexo">
                        <input type="radio" value="M" name="sexo"> Masculino <br>
                        <input type="radio" value="F" name="sexo"> Feminino <br>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                    <button type="button" class="btn btn-primary" id="btnSalvar">Salvar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal de Confirmação de Exclusão -->
    <div class="modal fade" id="confirmDeleteModal" tabindex="-1" role="dialog" aria-labelledby="confirmDeleteModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="confirmDeleteModalLabel">Confirmar Exclusão</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Deseja realmente excluir esta pessoa?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-danger" id="confirmDeleteBtn">Excluir</button>
                </div>
            </div>
        </div>
    </div>
   
<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>

<!-- Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

<!-- SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</body>

</html>
