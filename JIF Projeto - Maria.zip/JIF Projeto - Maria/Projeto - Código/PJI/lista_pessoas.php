<?php
session_start();

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: login.php");
    exit();
}

include('config.php');

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="css_2/style_atleta.css">
    <link rel="shortcut icon" href="img/Logo.ico">
    <title>Lista de Pessoas</title>

</head>
<style>
    .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .back-button {
        padding: 10px;
        text-decoration: none;
        background-color: green; 
        border: none;
        border-radius: 20px;
        color: white;
        cursor: pointer;
        font-size: 16px;
        transition: all 0.4s ease;
    }

    .back-button:hover {
        background-color: darkgreen; 
    } 

</style>

<body>
    
    <div class="boxzinha">
        <div class="formulario-boxzinha">
            <div class="header">
                <h2>Gerenciamento de Pessoas</h2>
                <a class="back-button" href="cadastros-gerais.php">Voltar</a>
            </div>
            
            <form method="POST" >
                <div class="inputszinha">
                    <label for="tipoSelect">Selecione o Tipo de Pessoa:</label>
                    <select id="tipoSelect" onchange="carregarPessoas()">
                    </select>
                </div>
            </form>

            <br><br>

            <h2>Lista de Pessoas</h2>
            <br>
            <table class="table">
                <thead class="table-light" id = "tableHeader">
                    


                </thead>
                <tbody id="pessoasTableBody">
                    <!-- A tabela será preenchida dinamicamente com JavaScript -->

                </tbody>
            </table>


        </div>
    </div>

    <!-- Modal de Edição Tipo: Chefe de Delegação e Outros -->
    <div class="modal fade" id="editarModal" tabindex="-1" role="dialog" aria-labelledby="editarModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editarModalLabel">Editar Pessoa</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    
                    <label for="editNome">Nome Completo</label>
                    <input type="text" id="editNome" name="editNome" required>
                    <br><br>
                    <label for="editCPF">CPF</label>
                    <input type="text" id="editCPF" name="editCPF" required>
                    <br><br>
                    <label for="editData">Data de Nascimento</label>
                    <input type="date" id="editData" name = "editData" required>
                    <br><br>
                    <label> Sexo: </label>
                    <div class="sexo">
                        <input type="radio" value="M" name="sexo"> Masculino <br>
                        <input type="radio" value="F" name="sexo"> Feminino <br>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                    <button type="button" class="btn btn-primary" id="btnSalvar">Salvar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal de Edição Tipo: Atleta -->
    <div class="modal fade" id="editarModalAtleta" tabindex="-1" role="dialog" aria-labelledby="editarModalAtletaLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editarModalAtletaLabel">Editar Atleta</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <label for="editResponsavel"> Responsável </label>
                    <input type="text" id="editResponsavel" name="editResponsavel" required>
                    <br><br>
                    <label for="editNomeAtleta"> Nome Completo </label>
                    <input type="text" id="editNomeAtleta" name="editNomeAtleta" required>
                    <br><br>
                    <label for="editCPFAtleta"> CPF </label>
                    <input type="text" id="editCPFAtleta" name="editCPFAtleta" required>
                    <br><br>
                    <label for="editRGAtleta"> RG </label>
                    <input type="text" id="editRGAtleta" name="editRGAtleta" required>
                    <br><br>
                    <label for="editRAAtleta"> RA (Prontuário) </label>
                    <input type="text" id="editRAAtleta" name="editRAAtleta" required>
                    <br><br>
                    <label for="editDataAtleta"> Data de Nascimento </label>
                    <input type="date" id="editDataAtleta" name = "editDataAtleta" required>
                    <br><br>
                    <label> Sexo: </label>
                    <div class="sexo">
                        <input type="radio" value="M" name="sexo"> Masculino <br>
                        <input type="radio" value="F" name="sexo"> Feminino <br>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                    <button type="button" class="btn btn-primary" id="btnSalvarAtleta">Salvar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal de Confirmação de Exclusão -->
    <div class="modal fade" id="confirmDeleteModal" tabindex="-1" role="dialog" aria-labelledby="confirmDeleteModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="confirmDeleteModalLabel">Confirmar Exclusão</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Deseja realmente excluir esta pessoa?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-danger" id="confirmDeleteBtn">Excluir</button>
                </div>
            </div>
        </div>
    </div>
   
<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>

<!-- Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

<!-- SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</body>

<script>
    $(document).ready(function () {
        
        // Carrega os tipos de pessoa no select
        $.ajax({
            url: 'getTiposPessoa.php',
            type: 'GET',
            dataType: 'json',
            success: function (data) {
                var select = $('#tipoSelect');
                $.each(data, function (index, tipo) {
                    select.append('<option value="' + tipo.id_tipo + '">' + tipo.descricao + '</option>');
                });

                // Seleciona o primeiro tipo e carrega as pessoas
                select.val(data[0].id_tipo);
                //console.log('Teste');
                console.log(data);
                carregarPessoas();
            }
        });

         // Função para carregar pessoas com base no tipo selecionado
        window.carregarPessoas = function () {
            var tipoId = $('#tipoSelect option:selected').val();
            
            $.ajax({
                url: 'carregarPessoas.php',  
                type: 'POST',
                data: { tipoId: tipoId },
                dataType: 'json',
                success: function (data) {
                    console.log(data);
                    // Limpa a tabela antes de preenchê-la
                    $('#pessoasTableBody').empty();
                    
                    if (data.length > 0) {
                        // Verifica o tipo para decidir qual tabela exibir
                        if (tipoId === '1') { // Exemplo: Se o tipo for 1 (Atleta)
                            construirCabecalhoAtleta();
                            preencherTabelaAtleta(data);
                        } else { // Outro tipo
                            construirCabecalhoOutro();
                            preencherTabelaOutro(data);
                        }
                    } else {
                        // Se não houver pessoas, exibe a mensagem "Nenhuma Pessoa Foi Inserida Ainda"
                        $('#tableHeader').empty();
                        $('#pessoasTableBody').html('<p> Nenhuma Pessoa Foi Inserida Ainda</p>');
                    }
                },
                error: function (xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        };

        function construirCabecalhoAtleta() {
            var header = '<tr>' +
                '<th scope="col" class="text-center">Responsável</th>' + 
                '<th scope="col" class="text-center">Nome</th>' +
                '<th scope="col" class="text-center">CPF</th>' +
                '<th scope="col" class="text-center">RG</th>' +
                '<th scope="col" class="text-center">RA</th>' +
                '<th scope="col" class="text-center">Data de Nascimento</th>' +
                '<th scope="col" class="text-center">Sexo</th>' +
                '<th scope="col" class="text-center">Editar</th>' +
                '<th scope="col" class="text-center">Excluir</th>' +
                '</tr>';
            $('#tableHeader').html(header);
        }

        // Função para construir o cabeçalho da tabela para Outros tipos
        function construirCabecalhoOutro() {
            var header = '<tr>' +
                '<th scope="col" class="text-center">Nome</th>' +
                '<th scope="col" class="text-center">CPF</th>' +
                '<th scope="col" class="text-center">Data de Nascimento</th>' +
                '<th scope="col" class="text-center">Sexo</th>' +
                '<th scope="col" class="text-center">Editar</th>' +
                '<th scope="col" class="text-center">Excluir</th>' +
                '</tr>';
            $('#tableHeader').html(header);
        }

        // Função para preencher a tabela para Atletas
        function preencherTabelaAtleta(data) {
          
            $.each(data, function (index, pessoa) {
                var row = '<tr>' +
                    '<td class="text-center">' + pessoa.responsavel + '</td>' +
                    '<td class="text-center">' + pessoa.nome + '</td>' +
                    '<td class="text-center">' + pessoa.cpf + '</td>' +
                    '<td class="text-center">' + pessoa.rg + '</td>' +
                    '<td class="text-center">' + pessoa.ra + '</td>' +
                    '<td class="text-center">' + pessoa.datanasc + '</td>' +
                    '<td class="text-center">' + pessoa.sexo + '</td>' +
                    '<td class="text-center"><button class="btn btn-primary" data-id="' + pessoa.id + '" onclick="abrirModalEditar(' + pessoa.id + ')">Editar</button></td>' +
                    '<td class="text-center"><button class="btn btn-danger" onclick="confirmarExclusao(\'' + pessoa.cpf + '\')">Excluir</button></td>' +
                    '</tr>';
                $('#pessoasTableBody').append(row);
            });
        }

        // Função para preencher a tabela para Outros tipos
        function preencherTabelaOutro(data) {
          
            $.each(data, function (index, pessoa) {
                var row = '<tr>' +
                    '<td class="text-center">' + pessoa.nome + '</td>' +
                    '<td class="text-center">' + pessoa.cpf + '</td>' +
                    '<td class="text-center">' + pessoa.datanasc + '</td>' +
                    '<td class="text-center">' + pessoa.sexo + '</td>' +
                    '<td class="text-center"><button class="btn btn-primary" data-id="' + pessoa.id + '" onclick="abrirModalEditar(' + pessoa.id + ')">Editar</button></td>' +
                    '<td class="text-center"><button class="btn btn-danger" onclick="confirmarExclusao(\'' + pessoa.cpf + '\')">Excluir</button></td>' +
                    '</tr>';
                $('#pessoasTableBody').append(row);
            });
        }

        // Função para abrir o modal de edição com os dados da pessoa
        window.abrirModalEditar = function (idPessoa) {

            // Obtem o tipo de pessoa selecionado
            var tipoId = $('#tipoSelect option:selected').val();

            // Adaptação para obter o tipo de pessoa correspondente
            $.ajax({
                url: 'carregarPessoas.php', 
                type: 'POST',
                data: { tipoId: tipoId },
                dataType: 'json',
                success: function (data) {
                    console.log('Dados recebidos:', data);
                    console.log('ID recebido:', tipoId);
                    idPessoa = tipoId;
                    if (data.length > 0) {
                        if (tipoId === '1') {
                                abrirModalEditarAtleta(idPessoa);
                        } else {
                            // Caso contrário, abre o modal genérico
                            abrirModalEditarComum(idPessoa);
        
                        }
                    } else {
                        console.error('Tipo de pessoa não encontrado.');
                    }
                }
            });
        };

        function abrirModalEditarAtleta(idPessoa) {
            console.log('Abrindo modal de Atleta para idPessoa:', idPessoa);
            
            $.ajax({
                url: 'getAtletaById.php', 
                type: 'POST',
                data: { idPessoa: idPessoa },
                dataType: 'json',
                success: function (data) {
                    console.log('Dados do Atleta:', data);
                    console.log('idPessoa:', idPessoa);

                    // Lógica para preencher os campos do modal de Atleta com os dados da pessoa
                    $('#editResponsavel').val(data.responsavel);
                    $('#editNomeAtleta').val(data.nome);
                    $('#editCPFAtleta').val(data.cpf);
                    $('#editRGAtleta').val(data.rg);
                    $('#editRAAtleta').val(data.ra);
                    $('#editDataAtleta').val(data.datanasc);
                    $("input[name='sexo'][value='" + data.sexo + "']").prop('checked', true);

                    // Abre o modal de edição de Atleta
                    $('#editarModalAtleta').modal('show');
                }
            });
        }

        function salvarAtleta() {
            // Obtenha os valores dos campos do modal de Atleta
            var responsavel = $('#editResponsavel').val();
            var nome = $('#editNomeAtleta').val();
            var cpf = $('#editCPFAtleta').val();
            var rg = $('#editRGAtleta').val();
            var ra = $('#editRAAtleta').val();
            var datanasc = $('#editDataAtleta').val();
            var sexo = $("input[name='sexo']:checked").val();  // Adicione esta linha

            // Use AJAX para enviar os dados ao servidor e salvar no banco de dados
            $.ajax({
                url: 'salvarAtleta.php',
                type: 'POST',
                data: {
                    responsavel: responsavel,
                    nome: nome,
                    cpf: cpf,
                    rg: rg,
                    ra: ra,
                    datanasc: datanasc,
                    sexo: sexo
                },
                success: function (response) {
                    console.log(response);
                    // Exibe uma mensagem de sucesso usando SweetAlert2
                    Swal.fire({
                        icon: 'success',
                        title: 'Atleta salvo com sucesso!',
                        showConfirmButton: false,
                        timer: 1500  // Fecha automaticamente após 1.5 segundos
                    });

                    // Fecha o modal de Atleta
                    $('#editarModalAtleta').modal('hide');
                    
                    // Recarrega a lista de pessoas após salvar o Atleta
                    carregarPessoas();
                }
            });
        }

        function abrirModalEditarComum(idPessoa) {
            console.log('Abrindo modal comum para idPessoa:', idPessoa);

            $.ajax({
                url: 'getPessoaById.php', 
                type: 'POST',
                data: { idPessoa: idPessoa },
                dataType: 'json',
                success: function (data) {
                    console.log('Dados da Pessoa:', data);
                    console.log('idPessoa:', idPessoa);

                    // Lógica para preencher os campos do modal com os dados da pessoa
                    $('#editNome').val(data.nome);
                    $('#editCPF').val(data.cpf);
                    $('#editData').val(data.datanasc);
                    $("input[name='sexo'][value='" + data.sexo + "']").prop('checked', true);

                    // Abre o modal 
                    $('#editarModal').modal('show');
                }
            });
        }
        
        function salvarPessoaComum() {
            var nome = $('#editNome').val();
            var cpf = $('#editCPF').val();
            var datanasc = $('#editData').val();
            var sexo = $("input[name='sexo']:checked").val();

            $.ajax({
                url: 'salvarPessoaComum.php', 
                type: 'POST',
                data: {
                    nome: nome,
                    cpf: cpf,
                    datanasc: datanasc,
                    sexo: sexo
                },
                success: function (response) {
                    console.log(response);
                    // Lógica de tratamento após salvar os dados da pessoa comum
                    Swal.fire({
                        icon: 'success',
                        title: 'Pessoa salva com sucesso!',
                        showConfirmButton: false,
                        timer: 1500  // Fecha automaticamente após 1.5 segundos
                    });

                    // Fecha o modal genérico
                    $('#editarModal').modal('hide');

                    carregarPessoas();
                }
            });
        }

         // Função para preencher a tabela de pessoas
        function preencherTabelaPessoas(data) {
            var tableBody = $('#pessoasTableBody');
            tableBody.empty();

            $.each(data, function (index, pessoa) {
                var row = '<tr>' +
                    '<td class="text-center">' + pessoa.nome + '</td>' +
                    '<td class="text-center">' + pessoa.cpf + '</td>' +
                    '<td class="text-center">' + pessoa.datanasc + '</td>' +
                    '<td class="text-center">' + pessoa.sexo + '</td>' +
                    '<td class="text-center"><button type="button" class="btn btn-primary" onclick="abrirModalEditar(' + pessoa.id + ')">Editar</button></td>' +
                    '<td class="text-center"><button type="button" class="btn btn-danger" onclick="confirmarExclusao(\'' + pessoa.cpf + '\')">Excluir</button></td>' +
                    '</tr>';

                tableBody.append(row);
            });
        }

        // window.excluirPessoa = function (idPessoa) {
        //     console.log('ID da Pessoa a ser excluída:', idPessoa);
        //     // Exibe o modal de confirmação de exclusão
        //     $('#confirmDeleteModal').modal('show');

        //     // Define a função de confirmação de exclusão no botão de confirmação
        //     $('#confirmDeleteBtn').off('click').on('click', function () {
        //         // AJAX para excluir a pessoa do banco de dados
        //         $.ajax({
        //             url: 'excluirPessoa.php',
        //             type: 'POST',
        //             data: { idPessoa: idPessoa },
        //             success: function (response) {
        //                 console.log(response); // Adicione esta linha para verificar a resposta do servidor

        //                 // Fecha o modal de confirmação de exclusão
        //                 $('#confirmDeleteModal').modal('hide');

        //                 // Recarrega a lista de pessoas
        //                 carregarPessoas();
        //             },
        //             error: function (xhr, status, error) {
        //                 console.error(xhr.responseText); // Adicione esta linha para verificar mensagens de erro
        //             }
        //         });
        //     });
        // };


        // Adicione um parâmetro para receber o idPessoa na função confirmarExclusao
        window.confirmarExclusao = function (idPessoa) {
            console.log('ID da Pessoa a ser excluída:', idPessoa);
            $('#confirmDeleteModal').modal('show');

            // Define a função de confirmação de exclusão no botão de confirmação
            $('#confirmDeleteBtn').off('click').on('click', function () {
                // AJAX para excluir a pessoa do banco de dados
                $.ajax({
                    url: 'excluirPessoa.php', 
                    type: 'POST',
                    data: { idPessoa: idPessoa },
                    success: function (response) {
                        console.log(response);
                        // Fecha o modal de confirmação de exclusão
                        $('#confirmDeleteModal').modal('hide');

                        // Exibe uma mensagem de sucesso usando SweetAlert2
                        Swal.fire({
                            icon: 'success',
                            title: 'Pessoa excluída com sucesso!',
                            showConfirmButton: false,
                            timer: 1500  // Fecha automaticamente após 1.5 segundos
                        });

                        // Recarrega a lista de pessoas após excluir
                        carregarPessoas();
                    },
                    error: function (xhr, status, error) {
                        console.error(xhr.responseText);
                        // Restante do seu código de manipulação de erro
                    }
                });
            });
        };


        $('#tipoSelect').on('change', function () {
            carregarPessoas();  // Chama carregarPessoas quando o tipo é alterado
        });

        // Adicione a lógica para o botão Salvar no modal genérico
        $('#btnSalvar').on('click', function () {
            salvarPessoaComum();
        });

        $('#btnSalvarAtleta').on('click', function () {
            salvarAtleta();
        });

        // Adicione um manipulador de eventos para o clique no botão "Editar"
        $('#pessoasTableBody').on('click', '.btn-primary', function() {
            // Obtenha o idPessoa da linha da tabela
            var idPessoa = $(this).closest('tr').find('.btn-primary').data('id');
            
            // Chame abrirModalEditar passando o idPessoa
            abrirModalEditar(idPessoa);
        });
});
</script>


</html>
