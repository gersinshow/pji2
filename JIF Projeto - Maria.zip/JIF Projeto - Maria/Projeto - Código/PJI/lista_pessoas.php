<?php
session_start();

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: login.php");
    exit();
}

include('config.php');

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="css_2/style_atleta.css">
    <link rel="shortcut icon" href="img/Logo.ico">
    <title>Lista de Pessoas</title>

</head>
<style>
    .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .back-button {
        padding: 5px 10px;
        text-decoration: none;
        background-color: green; 
        border: none;
        border-radius: 20px;
        color: white;
        cursor: pointer;
        font-size: 16px;
        transition: all 0.4s ease;
    }

    .back-button:hover {
        background-color: darkgreen; 
    } 

</style>

<body>
    
    <div class="boxzinha">

        <div class="formulario-boxzinha">
            <div class="header">
                <h2>Gerenciamento de Pessoas</h2>
                <a class="back-button" href="cadastros-gerais.php">Voltar</a>
            </div>
            
            <form action="#" method="POST" >
                <div class="inputszinha">
                    <label for="tipoSelect">Selecione o Tipo de Pessoa:</label>
                    <select id="tipoSelect" onchange="carregarPessoas()">
                        
                    </select>
                </div>
            </form>

            <br><br>

            <h2>Lista de Pessoas</h2>
            <br>
            <table class="table">
                <thead>
                    <tr>
                        <th class="text-center">ID</th>
                        <th class="text-center">Nome</th>
                        <th class="text-center">CPF</th>
                        <th class="text-center">Data de Nascimento</th>
                        <th class="text-center">Sexo</th>
                        <th class="text-center">Editar</th>
                        <th class="text-center">Excluir</th>
                    </tr>
                </thead>
                <tbody id="pessoasTableBody">
                    <!-- A tabela será preenchida dinamicamente com JavaScript -->

                </tbody>
            </table>


        </div>
    </div>

    <!-- Modal de Edição Tipo: Chefe de Delegação e Outros -->
    <div class="modal fade" id="editarModal" tabindex="-1" role="dialog" aria-labelledby="editarModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editarModalLabel">Editar Pessoa</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="user_id" name="id">
                    <label for="editNome">Nome Completo</label>
                    <input type="text" id="editNome" name="editNome" required>
                    <br><br>
                    <label for="editCPF">CPF</label>
                    <input type="text" id="editCPF" name="editCPF" required>
                    <br><br>
                    <label for="editData">Data de Nascimento</label>
                    <input type="date" id="editData" name = "editData" required>
                    <br><br>
                    <label> Sexo: </label>
                    <div class="sexo">
                        <input type="radio" value="M" name="sexo"> Masculino <br>
                        <input type="radio" value="F" name="sexo"> Feminino <br>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                    <button type="button" class="btn btn-primary" id="btnSalvar">Salvar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal de Edição Tipo: Atleta -->
    <div class="modal fade" id="editarModalAtleta" tabindex="-1" role="dialog" aria-labelledby="editarModalAtletaLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editarModalAtletaLabel">Editar Atleta</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="user_id" name="id">
                    <label for="editResponsavel"> Nome Completo do Responsável </label>
                    <input type="text" id="editResponsavel" name="editResponsavel" required>
                    <label for="editNomeAtleta">Nome Completo</label>
                    <input type="text" id="editNomeAtleta" name="editNomeAtleta" required>
                    <br><br>
                    <label for="editCPFAtleta">CPF</label>
                    <input type="text" id="editCPFAtleta" name="editCPFAtleta" required>
                    <br><br>
                    <label for="editRGAtleta">RG</label>
                    <input type="text" id="editRGAtleta" name="editRGAtleta" required>
                    <label for="editRAAtleta">RA (Prontuário)</label>
                    <input type="text" id="editRAAtleta" name="editRAAtleta" required>
                    <label for="editDataAtleta">Data de Nascimento</label>
                    <input type="date" id="editDataAtleta" name = "editDataAtleta" required>
                    <br><br>
                    <label> Sexo: </label>
                    <div class="sexo">
                        <input type="radio" value="M" name="sexo"> Masculino <br>
                        <input type="radio" value="F" name="sexo"> Feminino <br>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                    <button type="button" class="btn btn-primary" id="btnSalvarAtleta">Salvar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal de Confirmação de Exclusão -->
    <div class="modal fade" id="confirmDeleteModal" tabindex="-1" role="dialog" aria-labelledby="confirmDeleteModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="confirmDeleteModalLabel">Confirmar Exclusão</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Deseja realmente excluir esta pessoa?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-danger" id="confirmDeleteBtn">Excluir</button>
                </div>
            </div>
        </div>
    </div>
   
<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>

<!-- Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

<!-- SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</body>

<script>
    $(document).ready(function () {
        // Carrega os tipos de pessoa no select
        $.ajax({
            url: 'getTiposPessoa.php',
            type: 'GET',
            dataType: 'json',
            success: function (data) {
                var select = $('#tipoSelect');
                $.each(data, function (index, tipo) {
                    select.append('<option value="' + tipo.id_tipo + '">' + tipo.descricao + '</option>');
                });

                // Seleciona o primeiro tipo e carrega as pessoas
                select.val(data[0].id_tipo);
                carregarPessoas();
            }
        });

         // Função para carregar pessoas com base no tipo selecionado
        window.carregarPessoas = function () {
            var tipoId = $('#tipoSelect option:selected').val();

            $.ajax({
                url: 'carregarPessoas.php',  
                type: 'POST',
                data: { tipoId: tipoId },
                dataType: 'json',
                success: function (data) {
                    // Limpa a tabela antes de preenchê-la
                    $('#pessoasTableBody').empty();

                    // Verifica o tipo para decidir qual tabela exibir
                    if (tipoId === '1') { // Exemplo: Se o tipo for 1 (Atleta)
                        preencherTabelaAtleta(data);
                    } else { // Outro tipo
                        preencherTabelaOutro(data);
                    }
                }
            });
        };

        // Função para preencher a tabela para Atletas
        function preencherTabelaAtleta(data) {
            // Adapte conforme a estrutura dos dados retornados (data)
            $.each(data, function (index, pessoa) {
                var row = '<tr>' +
                    '<td class="text-center">' + pessoa.id + '</td>' +
                    '<td class="text-center">' + pessoa.responsavel + '</td>' +
                    '<td class="text-center">' + pessoa.nome + '</td>' +
                    '<td class="text-center">' + pessoa.cpf + '</td>' +
                    '<td class="text-center">' + pessoa.rg + '</td>' +
                    '<td class="text-center">' + pessoa.ra + '</td>' +
                    '<td class="text-center">' + pessoa.datanasc + '</td>' +
                    '<td class="text-center">' + pessoa.sexo + '</td>' +
                    '<td class="text-center"><button class="btn btn-primary" onclick="abrirModalEditar(' + pessoa.id + ')">Editar</button></td>' +
                    '<td class="text-center"><button class="btn btn-danger" onclick="confirmarExclusao(' + pessoa.id + ')">Excluir</button></td>' +
                    '</tr>';
                $('#pessoasTableBody').append(row);
            });
        }

        // Função para preencher a tabela para Outros tipos
        function preencherTabelaOutro(data) {
            // Adapte conforme a estrutura dos dados retornados (data)
            $.each(data, function (index, pessoa) {
                var row = '<tr>' +
                    '<td class="text-center">' + pessoa.id + '</td>' +
                    '<td class="text-center">' + pessoa.nome + '</td>' +
                    '<td class="text-center">' + pessoa.cpf + '</td>' +
                    '<td class="text-center">' + pessoa.datanasc + '</td>' +
                    '<td class="text-center">' + pessoa.sexo + '</td>' +
                    '<td class="text-center"><button class="btn btn-primary" onclick="abrirModalEditar(' + pessoa.id + ')">Editar</button></td>' +
                    '<td class="text-center"><button class="btn btn-danger" onclick="confirmarExclusao(' + pessoa.id + ')">Excluir</button></td>' +
                    '</tr>';
                $('#pessoasTableBody').append(row);
            });
        }

        // Função para abrir o modal de edição com os dados da pessoa
        window.abrirModalEditar = function (idPessoa) {
            // Obtem o tipo de pessoa selecionado
            var tipoId = $('#tipoSelect option:selected').val();

            // Adaptação para obter o tipo de pessoa correspondente
            $.ajax({
                url: 'getTipoPessoaById.php', 
                type: 'POST',
                data: { tipoId: tipoId },
                dataType: 'json',
                success: function (data) {
                    var tipoPessoa = data.descricao;

                    if (tipoPessoa === 'Atleta') {
                        // Se for Atleta, abre o modal de edição específico para Atleta
                        abrirModalEditarAtleta(idPessoa);
                    } else {
                        // Caso contrário, abre o modal genérico
                        abrirModalEditarComum(idPessoa);
                    }
                }
            });
        };

        function abrirModalEditarAtleta(idPessoa) {
            $.ajax({
                url: 'getAtletaById.php', 
                type: 'POST',
                data: { idPessoa: idPessoa },
                dataType: 'json',
                success: function (data) {
                    // Lógica para preencher os campos do modal de Atleta com os dados da pessoa
                    $('#user_id').val(data.id);
                    $('#editResponsavel').val(data.responsavel);
                    $('#editNomeAtleta').val(data.nome);
                    $('#editCPFAtleta').val(data.cpf);
                    $('#editRGAtleta').val(data.rg);
                    $('#editRAAtleta').val(data.ra);
                    $('#editDataAtleta').val(data.datanasc);
                    $('#sexo').val(data.sexo);
                  
                    // Abre o modal de edição de Atleta
                    $('#editarModalAtleta').modal('show');
                }
            });
        }

        function salvarAtleta() {
            // Obtenha os valores dos campos do modal de Atleta
            var id = $('#user_id').val();
            var responsavel = $('#editResponsavel').val();
            var nome = $('#editNomeAtleta').val();
            var cpf = $('#editCPFAtleta').val();
            var rg = $('#editRGAtleta').val();
            var ra = $('#editRAAtleta').val();
            var datanasc = $('#editDataAtleta').val();
            var sexo = $("input[name='sexo']:checked").val();

            // Use AJAX para enviar os dados ao servidor e salvar no banco de dados
            $.ajax({
                url: 'salvarAtleta.php', 
                type: 'POST',
                data: {
                    id: id,
                    responsavel: responsavel,
                    nome: nome,
                    cpf: cpf,
                    rg: rg,
                    ra: ra,
                    datanasc: datanasc,
                    sexo: sexo
                },
                success: function (response) {
                    // Exibe uma mensagem de sucesso usando SweetAlert2
                    Swal.fire({
                        icon: 'success',
                        title: 'Atleta salvo com sucesso!',
                        showConfirmButton: false,
                        timer: 1500  // Fecha automaticamente após 1.5 segundos
                    });

                    // Fecha o modal de Atleta
                    $('#editarModalAtleta').modal('hide');
                    
                    // Recarrega a lista de pessoas após salvar o Atleta
                    carregarPessoas();
                }
            });
        }

        function abrirModalEditarComum(idPessoa) {
            $.ajax({
                url: 'getPessoaById.php', 
                type: 'POST',
                data: { idPessoa: idPessoa },
                dataType: 'json',
                success: function (data) {
                    // Lógica para preencher os campos do modal genérico com os dados da pessoa
                    $('#user_id').val(data.id);
                    $('#editNome').val(data.nome);
                    $('#editCPF').val(data.cpf);
                    $('#editData').val(data.datanasc);
                    $('#sexo').val(data.sexo);

                    // Abre o modal genérico
                    $('#editarModal').modal('show');
                }
            });
        }

        function salvarPessoaComum() {
            var id = $('#user_id').val();
            var nome = $('#editNome').val();
            var cpf = $('#editCPF').val();
            var datanasc = $('#editData').val();
            var sexo = $("input[name='sexo']:checked").val();

            // Adicione a lógica para salvar os dados da pessoa comum (usando AJAX ou outra abordagem)
            $.ajax({
                url: 'salvarPessoaComum.php', // Substitua pelo nome do arquivo que salva os dados da pessoa comum
                type: 'POST',
                data: {
                    id: id,
                    nome: nome,
                    cpf: cpf,
                    datanasc: datanasc,
                    sexo: sexo
                },
                success: function (response) {
                    // Lógica de tratamento após salvar os dados da pessoa comum
                    Swal.fire({
                        icon: 'success',
                        title: 'Pessoa salva com sucesso!',
                        showConfirmButton: false,
                        timer: 1500  // Fecha automaticamente após 1.5 segundos
                    });

                    // Fecha o modal genérico
                    $('#editarModal').modal('hide');
                }
            });
        }

         // Função para preencher a tabela de pessoas
        function preencherTabelaPessoas(data) {
            var tableBody = $('#pessoasTableBody');
            tableBody.empty();

            $.each(data, function (index, pessoa) {
                var row = '<tr>' +
                    '<td class="text-center">' + pessoa.id + '</td>' +
                    '<td class="text-center">' + pessoa.nome + '</td>' +
                    '<td class="text-center">' + pessoa.cpf + '</td>' +
                    '<td class="text-center">' + pessoa.datanasc + '</td>' +
                    '<td class="text-center">' + pessoa.sexo + '</td>' +
                    '<td class="text-center"><button type="button" class="btn btn-primary" onclick="abrirModalEditar(' + pessoa.id + ')">Editar</button></td>' +
                    '<td class="text-center"><button type="button" class="btn btn-danger" onclick="confirmarExclusao(' + pessoa.id + ')">Excluir</button></td>' +
                    '</tr>';

                tableBody.append(row);
            });
        }

        // Função para realizar a exclusão após a confirmação
        window.excluirPessoa = function (idPessoa) {
            // Exibe o modal de confirmação de exclusão
            $('#confirmDeleteModal').modal('show');

            // Define a função de confirmação de exclusão no botão de confirmação
            $('#confirmDeleteBtn').off('click').on('click', function () {
                // AJAX para excluir a pessoa do banco de dados
                $.ajax({
                    url: 'excluirPessoa.php',
                    type: 'POST',
                    data: { idPessoa: idPessoa },
                    success: function () {
                        // Fecha o modal de confirmação de exclusão
                        $('#confirmDeleteModal').modal('hide');
                        
                        // Recarrega a lista de pessoas
                        carregarPessoas();
                    }
                });
            });
        };

        // Função para confirmar a exclusão
        window.confirmarExclusao = function (idPessoa) {
            // Adicione a lógica para exibir o modal de confirmação de exclusão
            $('#confirmDeleteModal').modal('show');

            // Define a função de confirmação de exclusão no botão de confirmação
            $('#confirmDeleteBtn').off('click').on('click', function () {
                // AJAX para excluir a pessoa do banco de dados
                $.ajax({
                    url: 'excluirPessoa.php', // Substitua pelo nome do arquivo que exclui a pessoa
                    type: 'POST',
                    data: { idPessoa: idPessoa },
                    success: function () {
                        // Fecha o modal de confirmação de exclusão
                        $('#confirmDeleteModal').modal('hide');

                        // Exibe uma mensagem de sucesso usando SweetAlert2
                        Swal.fire({
                            icon: 'success',
                            title: 'Pessoa excluída com sucesso!',
                            showConfirmButton: false,
                            timer: 1500  // Fecha automaticamente após 1.5 segundos
                        });

                        // Recarrega a lista de pessoas após excluir
                        carregarPessoas();
                    }
                });
            });
        };


        // Adicione a lógica para o botão Salvar no modal genérico
        $('#btnSalvar').on('click', function () {
            salvarPessoaComum();
        });

        // Adicione a lógica para o botão Salvar no modal de Atleta
        $('#btnSalvarAtleta').on('click', function () {
            salvarAtleta();
        });
});
</script>


</html>
