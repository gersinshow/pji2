function updateTable() {
    console.log('Chamando updateTable...');
    $.ajax({
        method: "GET",
        url: "code_unidades.php?action=updateTable",
        dataType: 'json',
        success: function (response) {
            console.log('Resposta da atualização:', response);
            
            // Limpa a tabela antes de adicionar novas linhas
            $('#tabelaUnidades tbody').empty();

            if (response.status === 'success') {
                var data = response.data;

                if (Array.isArray(data) && data.length > 0) {
                    $.each(data, function (index, row) {
                        var newRow = '<tr>' +
                            '<td class="text-center user_id">' + row['id_unidade'] + '</td>' +
                            '<td class="text-center">' + row['sigla_instituicao'] + '</td>' +
                            '<td class="text-center">' + row['campus'] + '</td>' +
                            '<td class="text-center">' +
                            '<a href="#" class="btn btn-primary edit_data"> Editar </a>' +
                            '</td>' +
                            '<td class="text-center">' +
                            '<a href="#" class="btn btn-danger confirm_delete_data" > Excluir </a>' +
                            '</td>' +
                            '</tr>';

                        $('#tabelaUnidades tbody').append(newRow);
                    });
                } else {
                    // Caso a tabela esteja vazia, exibir mensagem
                    $('#tabelaUnidades tbody').append('<tr><td colspan="5" class="text-center">Nenhuma Unidade Foi Inserida Ainda</td></tr>');
                }
            } else if (response.status === 'empty') {
                // Caso a tabela esteja vazia, exibir mensagem
                $('#tabelaUnidades tbody').append('<tr><td colspan="5" class="text-center">Nenhuma Unidade Foi Inserida Ainda</td></tr>');
            } else if ('error' in response) {
                console.log('Error:', response.error);
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log('AJAX Error:', textStatus, errorThrown);
        }
    });
}

const cadUsuarioForm = document.getElementById("cad-usuario-form");

// Verificar se a constante cadUsuarioForm é TRUE
if (cadUsuarioForm) {
    // Aguardar e identificar o clique do usuário no botão cadastrar com JavaScript
    cadUsuarioForm.addEventListener("submit", async (e) => {
        e.preventDefault();
    
        const sigla = document.getElementById("sigla").value;
        const campus = document.getElementById("campus").value;
    
        // Verificar se os campos estão preenchidos
        if (sigla.trim() === "" || campus.trim() === "") {
            Swal.fire({
                text: "Erro: Campos 'sigla' e 'campus' são obrigatórios!",
                icon: 'error',
                showCancelButton: false,
                confirmButtonColor: '#3085d6',
                confirmButtonText: 'Fechar',
            });
            return;
        }
    
        const dadosForm = new URLSearchParams(new FormData(cadUsuarioForm));
    
        const dados = await fetch("cadastrar_unidade.php", {
            method: "POST",
            body: dadosForm,
        });
    
        const resposta = await dados.json();
    
        if (resposta['status'] === true) {
            console.log('Inserção bem-sucedida!');
            Swal.fire({
                text: resposta['msg'],
                icon: 'success',
                showCancelButton: false,
                confirmButtonColor: '#3085d6',
                confirmButtonText: 'Fechar',
            });
            
            // Chama a função updateTable somente após a inserção bem-sucedida
            updateTable();

            cadUsuarioForm.reset();
        } else {
            Swal.fire({
                text: resposta['msg'],
                icon: 'error',
                showCancelButton: false,
                confirmButtonColor: '#3085d6',
                confirmButtonText: 'Fechar',
            });

            
        }

    });
}
