<?php
session_start();

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css_2/style_equipe.css">
    <link rel="shortcut icon" href="img/Logo.ico">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <title>Cadastro das Equipes</title>
</head>
<style>
    .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .back-button {
        padding: 5px 10px;
        text-decoration: none;
        background-color: green; 
        border: none;
        border-radius: 20px;
        color: white;
        cursor: pointer;
        font-size: 16px;
        transition: all 0.4s ease;
    }

    .back-button:hover {
        background-color: darkgreen; 
    }
</style>
<body>
    <div class="boxzinha">
        <div class="formulario-boxzinha">
            <div class="header">
                <h2>Cadastro das Equipes</h2>
                <a class="back-button" href="cadastros-gerais.php">Voltar</a>
            </div>

            <form action="#">
                <div class="inputszinha">
                    <label for="campeonato">Campeonato:</label>
                    <select name="camp" id="camp">
                        <option value="">Selecione o Campeonato da Equipe</option>
                        <option value="jif2023">JIF 2023</option>
                    </select>
                </div>
                <div class="inputszinha">
                    <label for="atletas">Atletas:</label>
                    <select name="atletas" id="atletas">
                        <option value="">Selecione os atletas</option>
                        <option value="">Atleta 1</option>
                        <option value="">btleta 2</option>
                        <option value="">barbara 4</option>
                        <option value="">dtleta 5</option>
                        <option value="">etleta 6</option>
                    </select>
                </div>
                <div class="inputszinha">
                    <label for="delegacao">Chefe de Delegação:</label>
                    <select name="delegacao" id="delegacao">
                        <option value="">Selecione o Chefe de Delegação</option>
                        <option value="">Chefe 1</option>
                        <option value="">Chefe 2</option>
                        <option value="">Chefe 3</option>
                    </select>
                </div>
                <div class="inputszinha">
                    <button>Cadastrar</button>
                </div>

            </form>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#camp').select2();
            $('#atletas').select2();
            $('#delegacao').select2();
        });
    </script>

</body>

</html>