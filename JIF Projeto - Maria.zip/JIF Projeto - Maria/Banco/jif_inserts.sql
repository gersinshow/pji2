-- Inserindo dados na tabela 'modalidade'
INSERT INTO modalidade (id_modalidade, nome) VALUES (1, 'Futebol');
INSERT INTO modalidade (id_modalidade, nome) VALUES (2, 'Basquete');
-- Adicione mais linhas conforme necessário.

-- Inserindo dados na tabela 'unidade'
INSERT INTO unidade (id_unidade, sigla_instituicao, campus) VALUES (1, 'IFSP', 'São Paulo');
INSERT INTO unidade (id_unidade, sigla_instituicao, campus) VALUES (2, 'IFSP', 'Araraquara');
-- Adicione mais linhas conforme necessário.

-- Inserindo dados na tabela 'tipo_pessoa'
INSERT INTO tipo_pessoa (descricao) VALUES ('Atleta');
INSERT INTO tipo_pessoa (descricao) VALUES ('Chefe de Delegação');
INSERT INTO tipo_pessoa (descricao) VALUES ('Outros');
-- Adicione mais linhas conforme necessário.

-- Inserindo dados na tabela 'pessoa'
INSERT INTO pessoa (cpf, nome, sexo, datanasc, rg, ra, responsavel, tipo_pessoa_id) 
VALUES ('111.222.333-44', 'Nome1', 'M', '1990-01-01', '123456789', 'RA123', 'Responsavel1', 1);
-- Adicione mais linhas conforme necessário.

-- Inserindo dados na tabela 'pessoa_tipo'
INSERT INTO pessoa_tipo (cpf_pessoa, id_tipo) VALUES ('111.222.333-44', 1);
-- Adicione mais linhas conforme necessário.

-- Inserindo dados na tabela 'campeonato'
INSERT INTO campeonato (id_campeonato, ano, titulo) VALUES (1, '2023', 'Campeonato1');
-- Adicione mais linhas conforme necessário.

-- Inserindo dados na tabela 'equipe'
INSERT INTO equipe (id_campeonato, id_modalidade, id_unidade, id_equipe, nome) 
VALUES (1, 1, 1, 1, 'Equipe1'),
(1, 1, 2, 2, 'Equipe2');
-- Adicione mais linhas conforme necessário.

-- Inserindo dados na tabela 'equipe_delegacao'
INSERT INTO equipe_delegacao (id_campeonato, id_modalidade, id_unidade, id_equipe, cpf, chefe) 
VALUES (1, 1, 1, 1, '111.222.333-44', 'S');
-- Adicione mais linhas conforme necessário.

-- Inserindo dados na tabela 'equipe_atleta'
INSERT INTO equipe_atleta (id_campeonato, id_modalidade, id_unidade, id_equipe, cpf) 
VALUES (1, 1, 1, 1, '111.222.333-44');
-- Adicione mais linhas conforme necessário.

-- Inserindo dados na tabela 'partida'
INSERT INTO partida (id_campeonato, id_modalidade, id_partida, id_unidade1, id_equipe1, id_unidade2, id_equipe2, 
cidade, local_partida, data, horario, categoria, arbitro1, arbitro2, apontador) 
VALUES (1, 1, 1, 1, 1, 2, 2, 'Cidade1', 'Estadio1', '2023-01-01', '12:00', 'Categoria1', 'Arbitro1', 'Arbitro2', 'Apontador1');
-- Adicione mais linhas conforme necessário.

-- Inserindo dados na tabela 'partida_equipes_escalacao'
INSERT INTO partida_equipes_escalacao (id_campeonato, id_modalidade, id_partida, id_unidade, id_equipe, cpf, iniciante, id_escalacao) 
VALUES (1, 1, 1, 1, 1, '111.222.333-44', 'S', 1);
-- Adicione mais linhas conforme necessário.

-- Inserindo dados na tabela 'partida_gols'
INSERT INTO partida_gols (id_campeonato, id_modalidade, id_partida, id_equipe, id_gol, id_escalacao, horario) 
VALUES (1, 1, 1, 1, 1, 1, '12:30');
-- Adicione mais linhas conforme necessário.
