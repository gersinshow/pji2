-- insert das modalidades
call inserir_modalidade(1, 'futebol de salao');
call inserir_modalidade(2, 'volei');
call inserir_modalidade(3, 'atletismo');

-- insert das unidades
call inserir_unidade(1, 'IFSP', 'Araraquara');
call inserir_unidade(2, 'IFSP', 'Sao Paulo');
call inserir_unidade(3, 'IFSP', 'Matao');
call inserir_unidade(4, 'IFSP', 'Barretos');
call inserir_unidade(5, 'IFGO', 'Goiania');

-- insert das pessoas
call inserir_pessoa('1234', 'Lucas Silva', 'M', '1971-09-25');
call inserir_pessoa('1235', 'Leonardo Oliveira', 'M', '1971-09-25');
call inserir_pessoa('1236', 'Igor Souza', 'M', '1971-09-25');
call inserir_pessoa('1237', 'Alisson Souza', 'M', '1971-09-25');
call inserir_pessoa('11', 'Pedro Golim', 'M', '1971-09-25');
call inserir_pessoa('12', 'Rodrigo Ferreira', 'M', '1971-09-25');
call inserir_pessoa('13', 'Caique Martins', 'M', '1971-09-25');
call inserir_pessoa('14', 'Nicolas Nascimento', 'M', '1971-09-25');
call inserir_pessoa('15', 'Gabriel Santos', 'M', '1971-09-25');
call inserir_pessoa('16', 'Leonardo arq', 'M', '1971-09-25');
call inserir_pessoa('17', 'Igor arq', 'M', '1971-09-25');
call inserir_pessoa('18', 'Alisson arq Souza', 'M', '1971-09-25');
call inserir_pessoa('19', 'Pedro arq Golim', 'M', '1971-09-25');
call inserir_pessoa('20', 'Rodrigo F', 'M', '1971-09-25');
call inserir_pessoa('21', 'Caique M', 'M', '1971-09-25');
call inserir_pessoa('22', 'Nicolas N', 'M', '1971-09-25');
call inserir_pessoa('23', 'Lucas arq2 Silva', 'M', '1971-09-25');
call inserir_pessoa('24', 'Leonardo arq2 Oliveira', 'M', '1971-09-25');
call inserir_pessoa('25', 'Igor arq2 Souza', 'M', '1971-09-25');
call inserir_pessoa('26', 'Alisson arq2 Souza', 'M', '1971-09-25');
call inserir_pessoa('27', 'Pedro arq2 Golim', 'M', '1971-09-25');
call inserir_pessoa('28', 'Rodrigo arq2 Ferreira', 'M', '1971-09-25');
call inserir_pessoa('29', 'Caique arq2 Martins', 'M', '1971-09-25');
call inserir_pessoa('30', 'Nicolas arq2 Nascimento', 'M', '1971-09-25');






