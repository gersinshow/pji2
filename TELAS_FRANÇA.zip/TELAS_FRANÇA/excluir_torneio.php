<?php
session_start();
include('config.php');

// Verifica se o usuário está autenticado como administrador
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['id'])) {
    // Obtém o ID do torneio da URL
    $id = $_GET['id'];

    // Exclui o torneio com o ID específico
    $sql = "DELETE FROM campeonato WHERE id_campeonato = $id";

    if ($conexao->query($sql) === TRUE) {
        $_SESSION['successMessage'] = "Torneio excluído com sucesso.";
    }
}

// Redireciona de volta para a página de listagem
header("Location: lista_torneio.php");
exit();
?>
