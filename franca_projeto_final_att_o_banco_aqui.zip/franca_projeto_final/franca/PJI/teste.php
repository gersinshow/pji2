<?php

$dbHost = '127.0.0.1';
$dbUsername = 'root';
$dbPassword = 'root';
$dbName = 'projeto_jif';
$dbPorta = 3307;

$conexao = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName, $dbPorta);

if ($conexao->connect_error) {
    die("Erro: " . $conexao->connect_error);
}

$sql = "SELECT * FROM pessoa";
$result = $conexao->query($sql); // Usando o método query da instância mysqli

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Processar os dados aqui, por exemplo:
        echo "cpf: " . $row["cpf"] . " - Nome: " . $row["nome"] . "<br>";
    }
} else {
    echo "Nenhum resultado encontrado.";
}

// Feche a conexão com o banco de dados
$conexao->close();
?>