<?php
function mpp_adiciona_menu_admin(){
    add_menu_page(
        "Meu primeiro plugin"
        ,"Mariazinha's Team Plugin"
        ,'manage_options'
        ,'mpp-admin'
        ,'pagina_admin_menu'
    );

    $hookname = add_submenu_page(
                'mpp-admin',
                'Inserir local',
                'Inserir local',
                'manage_options',
                'mpp-inserir-local',
                'pagina_inserir_local'
                );

    add_action( 'load-'.$hookname,  'insere_local_no_banco');

    add_submenu_page(
        'mpp-admin',
        'Visualizar local',
        'Visualizar local',
        'manage_options',
        'mpp-visualizar-local',
        'pagina_visualizar_local'
    );

    $hookname = add_submenu_page(
                null,
                'Excluir local',
                'Excluir local',
                'manage_options',
                'mpp-excluir-local',
                'pagina_excluir_local'
            );

    add_action( 'load-'.$hookname,  'remove_local_no_banco');
    
    $hookname = add_submenu_page(
        null,
        'Editar local',
        'Editar local',
        'manage_options',
        'mpp-editar-local',
        'pagina_editar_local'
    );

add_action( 'load-'.$hookname,  'atualiza_local_no_banco');  
}

add_action('admin_menu','mpp_adiciona_menu_admin');

function pagina_admin_menu(){
    include plugin_dir_path(__FILE__)."pages/mpp-painel-opcoes.php";
}

function pagina_excluir_local(){
    include plugin_dir_path(__FILE__)."pages/mpp-excluir-local.php";
}

function pagina_editar_local(){
    include plugin_dir_path(__FILE__)."pages/mpp-editar-local.php";
}

function pagina_visualizar_local(){
    include plugin_dir_path(__FILE__)."pages/mpp-visualizar-local.php";
}

function pagina_inserir_local(){
    include plugin_dir_path(__FILE__)."pages/mpp-inserir-local.php";
}

function insere_local_no_banco(){
    global $wpdb;
    $nome_da_tabela = $wpdb->prefix."mpp_locais";
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $wpdb->insert($nome_da_tabela,
            array(
                'local' => $_POST['local'],
                'data' => $_POST["data"],
                'hora' => $_POST["hora"],
                'equipes' => $_POST["equipes"]
            ));
    }
}


function getlocal(){
    global $wpdb;
    $nome_da_tabela = $wpdb->prefix."mpp_locais";
    $resultado = null;

    if($_SERVER['REQUEST_METHOD'] == 'GET'){
        $sql = "SELECT id, local, data, hora, equipes FROM $nome_da_tabela";
        $resultado = $wpdb->get_results($sql);                
    }

    return $resultado;
}



function getlocalPorId($id){
    global $wpdb;
    $nome_da_tabela = $wpdb->prefix."mpp_locais";
    $resultado = null;

    if($_SERVER['REQUEST_METHOD'] == 'GET'){
        $sql = "SELECT id, local, data, hora, equipes FROM $nome_da_tabela where id = $id";
        $resultado = $wpdb->get_row($sql);                
    }

    return $resultado;
}

function excluirlocal($id){
    global $wpdb;
    $nome_da_tabela = $wpdb->prefix."mpp_locais";    

    return $wpdb->delete( $nome_da_tabela, array( 'id' => $id ));
}

function remove_local_no_banco(){
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        if(excluirlocal($_POST['id'])){
            header('Location: '. menu_page_url( 'mpp-admin',false));
       }
    }
}

function editarlocal($id, $local, $data, $hora, $equipes){
    global $wpdb;
    $nome_da_tabela = $wpdb->prefix."mpp_locais"; 
    return $wpdb->update( $nome_da_tabela, array('local' => $local, 'data' => $data, 'hora' => $hora, 'equipes' => $equipes ), array('id' => $id));
    
}

function atualiza_local_no_banco(){
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        if(editarlocal($_POST['id'], $_POST['local'], $_POST['data'], $_POST["hora"], $_POST["equipes"])){
            header('Location: '. menu_page_url( 'mpp-admin',false));
       }
    }
}

//[foobar]
// function mostrarlocal($atts){
//     $res = getlocal();

// 	$html = "<table>";
//     $html .= "<th>ID</th>";
//     $html .= "<th>local</th>";    
//     $html .= "<tbody>";    

//     foreach($res as $r):
//         $html .= "<tr>";
//         $html .=    "<td>".$r->id."</td>";
//         $html .=    "<td>".$r->mensagem."</td>";    
//         $html .= "</tr>";
//     endforeach;
    
//     $html.= "</tbody>";
//     $html.= "</table>";
    
//     return $html;
// }

// function mostrarlocalPorId($atts){

// }

// add_shortcode( 'mostrarlocal', 'mostrarlocal' );
// add_shortcode( 'mostrarlocalPorId', 'mostrarlocalPorId' );

// // [bartag foo="foo-value"]
// function buscalocal( $atts ) {
// 	$b = shortcode_atts( array(
// 		'id' => '-1',
// 	), $atts );

//     $local = getlocalPorId($b['id']);
//     if($local != null){
//         return $local->mensagem;
//     }else{
//         return;
//     }
	
// }
// add_shortcode( 'buscalocal', 'buscalocal' );

?>