<h1 class="text-center">Mariazinha's Team Plugin</h1>
<br>
<style>
    #div1 p {
        font-size: 17px;
    }
    .container p{
        font-size: 15px;
    }

    img{
        width: 95%;
        
    }
</style>
<div class="container" id="div1">
    <p>
    Os locais escolhidos para sediar os Jogos do JIF desempenham um papel fundamental na 
    atmosfera competitiva e colaborativa do evento. Cada local selecionado não apenas serve como palco para as competições esportivas, 
    mas também reflete a diversidade geográfica e cultural das instituições participantes. Esses espaços se transformam em arenas vibrantes, onde atletas, 
    treinadores e espectadores se reúnem para celebrar o espírito esportivo e a excelência acadêmica.
    </p>
</div>
<br>
<div class="container">
    <p>Use o painel Inserir local para adicionar locais de jogos</p>
    <p>Use o painel Visualizar local para visualizar locais de jogos</p>
    <img src="https://cdn.ocp.news/2023/10/alunos-jubs4.jpeg" alt="" srcset="">
</div>



<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
