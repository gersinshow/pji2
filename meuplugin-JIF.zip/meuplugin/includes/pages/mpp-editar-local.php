<?php 

if(isset($_GET['id'])){
    $id = $_GET['id'];
    $r = getlocalPorId($id);
}
?>


<form action="<?php menu_page_url( 'mpp-editar-local' ); ?>" method="post">
    
    <input type="hidden" name="id" id="id" value="<?= $id ?>">
    <label for="">Local:</label><br>
    <input type="text" name="local" id="local" value="<?= $r->local ?>"/>
    <br><label for="">Data:</label><br>
    <input type="date" name="data" id="data" value="<?= $r->data ?>">
    <br><label for="">Hora:</label><br>
    <input type="time" name="hora" id="hora" value="<?= $r->hora ?>">
    <br><label for="">Equipes:</label><br>
    <input type="text" name="equipes" id="equipes" value="<?= $r->equipes ?>">
    <br><br>
    <input type="submit" value="Editar" class="btn btn-outline-warning">
</form>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

