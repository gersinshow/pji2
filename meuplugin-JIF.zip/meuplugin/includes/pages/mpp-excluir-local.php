<?php 

if(isset($_GET['id'])){
    $id = $_GET['id'];
    $r = getlocalPorId($id);
}
?>
<h1>Excluir local</h1>
<h3>Local a ser excluído:<?= $r->local ?></h3>

<form action="<?php menu_page_url( 'mpp-excluir-local' ); ?>" method="post">
    <input type="hidden" name="id" id="id" value="<?= $id ?>">
    <input type="submit" value="Excluir" class="btn btn-outline-danger">
</form>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

