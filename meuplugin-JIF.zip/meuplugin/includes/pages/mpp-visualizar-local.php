<?php $res = getlocal(); ?>
<h1 class="text-center">Locais dos jogos</h1>
<br>
<table class="table table-striped table-hover w-50 p-3 mx-auto">    
    <th>ID</th>
    <th>Local</th>
    <th>Data</th>
    <th>Hora</th>
    <th>Equipes</th>
    <th>Excluir</th>
    <th>Editar</th>
    <tbody>
    <?php foreach($res as $r): ?>
        <tr>
            <td><?= $r->id;?></td>
            <td><?= $r->local;?></td>
            <td><?= $r->data;?></td>
            <td><?= $r->hora;?></td>
            <td><?= $r->equipes;?></td>
            <td> <a href="<?= menu_page_url( 'mpp-excluir-local',false).'&id='.$r->id; ?>"> Excluir </a> </td>
            <td> <a href="<?= menu_page_url( 'mpp-editar-local',false).'&id='.$r->id; ?>"> Editar </a> </td>
        </tr>
    <?php endforeach; ?>


    </tbody>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

</table>