<?php
/*
 * Plugin Name: Mariazinha's Team Plugin
 * Plugin URI:  https://arq.ifsp.edu.br
 * Description: Plugin final
 * Version: 1.0
 * Author: Gabriel França Santos, Gerson Rapattoni e Maria Eduarda Zanetti */

 require_once plugin_dir_path(__FILE__) . 'includes/mpp-functions.php';

 register_activation_hook(__FILE__, "mpp_activate");
 register_deactivation_hook(__FILE__,'mpp_deactivate');

 function mpp_activate(){
    //configuracoes de inicialização do plugin
    global $wpdb;

    $nome_da_tabela = $wpdb->prefix . "mpp_locais";

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $nome_da_tabela(
        id int(9) NOT NULL AUTO_INCREMENT,
        local text NOT NULL,
        data date NOT NULL,
        hora time NOT NULL,
        equipes text NOT NULL,
        PRIMARY KEY (id)) $charset_collate;";
    
    $wpdb->query($sql);
}

function mpp_deactivate(){
    global $wpdb;    
    $nome_da_tabela = $wpdb->prefix . "mpp_locais";
    $sql = "DROP TABLE $nome_da_tabela;";    
    $wpdb->query($sql);    
}
?>