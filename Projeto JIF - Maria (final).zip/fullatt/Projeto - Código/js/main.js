function createGame(name1, gols,name2) {
   return `
   <li>
      <div class="sele1">
         <div class="nome1">${name1}</div>
      </div>
      <div class="placar">
         <strong>${gols}</strong>
      </div>
      <div class="sele2">
         <div class="nome2">${name2}</div>
      </div>
   </li>
   `
}

let delay = - 0.4;
function createCard(date, day, games) {
   delay = delay + 0.4;
   return `
   <div class="card" style="animation-delay: ${delay}s">
		<h2>${date}<span>${day}</span></h2>
      <ul>
         ${games}
      </ul>
	</div>
   `
}


document.querySelector("#cards").innerHTML = 
   
   createCard("Partida", "$idpartida", 
   createGame("$equipe1", "1 X 2", "$equipe2")) 
 
   