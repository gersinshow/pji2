<?php
session_start();
include('config.php');

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: login.php");
    exit();
}

$tipo_pessoa_param = isset($_GET["tipo"]) ? $_GET["tipo"] : (isset($_POST["tipo"]) ? $_POST["tipo"] : "");

// Mapear o tipo de pessoa para o ID correspondente
$tipos_mapeados = [
    'atleta' => 1,
    'chefe' => 2,
    'outros' => 3,
];

// Verificar se o tipo de pessoa é válido
if ($tipo_pessoa_param && array_key_exists($tipo_pessoa_param, $tipos_mapeados)) {
    // Tipo de pessoa é válido
    $tipo_pessoa_id = $tipos_mapeados[$tipo_pessoa_param];
    //echo "Tipo de pessoa param: " . $tipo_pessoa_param;  // Debug
} else {
    // Tipo de pessoa inválido, redirecionar ou tratar conforme necessário
    //die("Tipo de pessoa inválido. Tipo de pessoa param: " . $tipo_pessoa_param);  // Debug
}

if(isset($_POST['submit'])) {

    if ($_SERVER['REQUEST_METHOD'] === 'POST') 
    {
        $diretorio_upload = "uploads/";

        // Nome dos arquivos no servidor
        $rgpdf_nome = $diretorio_upload . basename($_FILES["rgpdf"]["name"]);
        $fotopdf_nome = $diretorio_upload . basename($_FILES["fotopdf"]["name"]);

        // Move os arquivos para o diretório de uploads
        move_uploaded_file($_FILES["rgpdf"]["tmp_name"], $rgpdf_nome);
        move_uploaded_file($_FILES["fotopdf"]["tmp_name"], $fotopdf_nome);

        // Obter os valores do formulário
        $responsavel = $_POST['responsavel'];
        $nome = $_POST['nome'];
        $cpf = $_POST['cpf'];
        $rg = $_POST['rg'];
        $ra = $_POST['ra'];
        $data_nasc = $_POST['data_nasc'];
        $sexo = $_POST['sexo'];

        if ($conexao->connect_error) {
            die("Erro na conexão com o banco de dados: " . $conexao->connect_error);
        }

        // Adapte o SQL para incluir os caminhos dos arquivos no banco de dados
        $sql_pessoa = "INSERT INTO pessoa (cpf, nome, sexo, datanasc, rg, ra, responsavel, foto_rg, foto_rosto, tipo_pessoa_id) 
                    VALUES ('$cpf', '$nome', '$sexo', '$data_nasc', '$rg', '$ra', '$responsavel', '$rgpdf_nome', '$fotopdf_nome', '$tipo_pessoa_id')";

        // if ($conexao->query($sql_pessoa) === TRUE) {
        //     echo "<script>
        //             Swal.fire({
        //                 icon: 'success',
        //                 title: 'Cadastro realizado com sucesso!',
        //                 showConfirmButton: false,
        //                 timer: 1500
        //             });
        //         </script>";
        // } else {
        //     echo "Erro ao cadastrar atleta: " . $conexao->error;
        // }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css_2/style_atleta.css">
    <link rel="shortcut icon" href="../img/Logo.ico">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <title>Cadastro do Atleta</title>
</head>
<style>
    .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .back-button {
        padding: 5px 10px;
        text-decoration: none;
        background-color: green; 
        border: none;
        border-radius: 20px;
        color: white;
        cursor: pointer;
        font-size: 16px;
        transition: all 0.4s ease;
    }

    .back-button:hover {
        background-color: darkgreen; 
    }
</style>
<body>
    <div class="boxzinha">
        <div class="formulario-boxzinha">
            <div class="header">
                <h2>Cadastro do Atleta</h2>
                <a class="back-button" href="lista_pessoas.php">Voltar</a>
            </div>

            <form action="cadastro_atleta.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="tipo" value="<?php echo $tipo_pessoa_param; ?>">
                <div class="inputszinha">
                    <label for="responsavel"> Nome Completo do Responsável </label>
                    <input type="text" id="responsavel" name="responsavel" placeholder = "Digite o nome do Responsável" required>
                </div>
                <div class="inputszinha">
                    <label for="nome"> Nome Completo Atleta</label>
                    <input type="text" id="nome" name="nome" placeholder="Digite o seu Nome Completo" required>
                </div>
                <div class="inputszinha">
                    <label for="cpf"> CPF </label>
                    <input type="text" id="cpf" name="cpf" placeholder="Digite o seu CPF" required>
                </div>
                <div class="inputszinha">
                    <label for="rg">RG</label>
                    <input type="text" id="rg" name="rg" placeholder="Digite o seu RG" required>
                </div>

                <div class="inputszinha">
                    <label for="ra">RA (Prontuário)</label>
                    <input type="text" id="ra" name="ra" placeholder="Digite o seu RA" required>
                </div>
                <div class="inputszinha">
                    <label for="data_nasc">Data de Nascimento</label>
                    <input type="date" id="data_nasc" name="data_nasc" required>
                </div>
                <div class="inputszinha">
                    <label> Sexo: </label>
                </div>

                <div class="sexo">
                    <input type="radio" value="M" name="sexo"> Masculino <br>
                    <input type="radio" value="F" name="sexo"> Feminino <br>
                </div>

                <div class="inputszinha">
                    <label for="rgpdf">Imagem do RG (PDF, máximo 1MB)</label>
                    <input type="file" class="form-control-file" id="rgpdf" name="rgpdf" accept=".pdf" required>
                </div>
                
                <div class="inputszinha">
                    <label for="fotopdf">Foto de Rosto (PDF, máximo 1MB)</label>
                    <input type="file" class="form-control-file" id="fotopdf" name="fotopdf" accept=".pdf" required>
                </div>

                <div class="inputszinha">
                    <button type="submit" name="submit">Cadastrar</button>
                </div>

            </form>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <?php
    // Sua lógica PHP aqui
    if (isset($_POST['submit'])) {
        // Sua lógica de processamento aqui

        if ($conexao->query($sql_pessoa) === TRUE) {
            echo "<script>
            Swal.fire({
                text: 'Atleta Cadastrado com Sucesso!',
                icon: 'success',
                showCancelButton: false,
                confirmButtonColor: '#3085d6',
                confirmButtonText: 'Fechar'
            });
            </script>";
        } else {
            echo "Erro ao cadastrar atleta: " . $conexao->error;
        }

        $conexao->close();
    }
    ?>

</body>

</html>