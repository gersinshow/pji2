<?php
include('config.php');

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Obtém o ID da partida a ser excluída
if (isset($_POST['id_partida'])) {
    $id_partida = $_POST['id_partida'];
} else {
    http_response_code(400);
    echo json_encode(array('mensagem' => 'ID da partida não fornecido.'));
    exit;
}

// Inicia uma transação para garantir consistência
$conexao->begin_transaction();

try {
    // Tentar excluir o registro na tabela cadastro_partida_rapida
    $sqlExcluirPartida = "DELETE FROM cadastro_partida_rapida WHERE id_partida = ?";
    $stmtExcluirPartida = $conexao->prepare($sqlExcluirPartida);
    $stmtExcluirPartida->bind_param('i', $id_partida);
    $stmtExcluirPartida->execute();

    // Comita a transação se tudo ocorrer sem erros
    $conexao->commit();

    // Responde com uma mensagem de sucesso em formato JSON
    echo json_encode(array('mensagem' => 'Partida excluída com sucesso.'));
} catch (mysqli_sql_exception $e) {
    // Lidar com a exceção do MySQLi
    error_log('Erro MySQLi: ' . $e->getMessage());

    // Verificar se o erro é devido a violação de chave estrangeira
    if (strpos($e->getMessage(), 'Cannot delete or update a parent row') !== false) {
        http_response_code(400);
        echo json_encode(array('mensagem' => 'Erro ao excluir partida. Existem dados associados em outras tabelas.'));
    } else {
        http_response_code(500);
        echo json_encode(array('mensagem' => 'Erro MySQLi ao excluir partida.', 'erro' => $e->getMessage()));
    }
} finally {
    // Fecha a conexão com o banco de dados
    $conexao->close();
}
?>
