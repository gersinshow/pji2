<?php

include('config.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verifique a conexão
    if ($conexao->connect_error) {
        die("Conexão falhou: " . $conexao->connect_error);
    }

    // Verifique se a chave 'idTorneio' está definida no array $_POST
    if (isset($_POST['idPartida'])) {
        // Evite SQL Injection escapando os parâmetros
        $id_partida = $conexao->real_escape_string($_POST['idPartida']);

        // Lógica para obter os detalhes da pessoa do banco de dados pelo ID
        // Substitua os campos e tabelas de acordo com a sua estrutura de banco de dados
        $sql = "SELECT p.id_partida, p.id_equipe1, p.id_equipe2, p.id_campeonato, p.data_partida, p.resultado_equipe1, p.resultado_equipe2, p.modalidade, e1.nome as nome_equipe1, e2.nome as nome_equipe2, c.titulo as nome_campeonato
            FROM cadastro_partida_rapida p
            INNER JOIN equipe e1 ON p.id_equipe1 = e1.id_equipe
            INNER JOIN equipe e2 ON p.id_equipe2 = e2.id_equipe
            INNER JOIN campeonato c ON p.id_campeonato = c.id_campeonato
            WHERE p.id_partida = '$id_partida'";
        $result = $conexao->query($sql);

        // Verifique se há resultados
        if ($result->num_rows > 0) {
            // Converta os resultados em um array associativo
            $partida = $result->fetch_assoc();

            // Libere os resultados e feche a conexão
            $result->close();
            $conexao->close();

            // Retorne o array associativo como JSON
            echo json_encode($partida);
            exit(); // Adicione esta linha para encerrar o script após o echo
        } else {
            // Se não houver resultados, retorne um array vazio como JSON
            echo json_encode(array());
            exit(); // Adicione esta linha para encerrar o script após o echo
        }
    } else {
        // Se a chave 'idTorneio' não estiver definida, retorne um array vazio como JSON
        echo json_encode(array());
        exit(); // Adicione esta linha para encerrar o script após o echo
    }
} else {
    // Retornar algum erro se a requisição não for do tipo POST
    http_response_code(400);
    echo json_encode(array('mensagem' => 'Erro na requisição.'));
}
?>
